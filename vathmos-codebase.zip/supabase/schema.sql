-- ==============================================================================
-- Vathmos - Supabase PostgreSQL Schema
-- Designed for In-RAM Zero-Retention Compliance + Multi-Tier Subscriptions
-- ==============================================================================

-- 1. PROFILES (extends supabase auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT,
    company_name TEXT,
    role_title TEXT DEFAULT 'Technical Recruiter',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on profiles
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own profile"
    ON public.profiles FOR SELECT
    USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
    ON public.profiles FOR UPDATE
    USING (auth.uid() = id);

-- 2. SUBSCRIPTIONS (Tracks Stripe & Razorpay billing status)
-- Tiers: 'free' ($0), 'starter' ($38/mo), 'growth' ($79/mo), 'agency' ($119/mo)
CREATE TABLE IF NOT EXISTS public.subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    tier TEXT NOT NULL DEFAULT 'free' CHECK (tier IN ('free', 'starter', 'growth', 'agency')),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'trialing', 'past_due', 'canceled', 'unpaid')),
    payment_provider TEXT CHECK (payment_provider IN ('stripe', 'razorpay')),
    provider_customer_id TEXT,
    provider_subscription_id TEXT,
    current_period_start TIMESTAMPTZ DEFAULT NOW(),
    current_period_end TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '30 days'),
    cancel_at_period_end BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_user_subscription UNIQUE (user_id)
);

-- Enable RLS on subscriptions
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own subscription"
    ON public.subscriptions FOR SELECT
    USING (auth.uid() = user_id);

-- 3. USAGE QUOTAS (Enforces CV evaluation limits per billing cycle)
-- Tier allowances:
-- Free: 5 CV evaluations total
-- Starter ($38): 100 CV evaluations / month
-- Growth ($79): 300 CV evaluations / month
-- Agency ($119): 750 CV evaluations / month
CREATE TABLE IF NOT EXISTS public.usage_quotas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    evaluations_used INT NOT NULL DEFAULT 0,
    evaluations_limit INT NOT NULL DEFAULT 5,
    cycle_reset_at TIMESTAMPTZ DEFAULT (NOW() + INTERVAL '30 days'),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT unique_user_quota UNIQUE (user_id)
);

-- Enable RLS on usage_quotas
ALTER TABLE public.usage_quotas ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own quota"
    ON public.usage_quotas FOR SELECT
    USING (auth.uid() = user_id);

-- 4. EVALUATION AUDIT LOGS (Zero-Retention Compliant)
-- CRITICAL LEGAL REQUIREMENT: Never store resume text, candidate names, or PII.
-- Only anonymized counts, timestamp, and score benchmarks are recorded for quota deduction.
CREATE TABLE IF NOT EXISTS public.evaluation_audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    candidate_count INT NOT NULL DEFAULT 1,
    ensemble_models TEXT NOT NULL DEFAULT 'gemini-3.7-flash,gemini-3.1-flash-lite',
    latency_ms INT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on audit logs
ALTER TABLE public.evaluation_audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own audit logs"
    ON public.evaluation_audit_logs FOR SELECT
    USING (auth.uid() = user_id);

-- 5. AUTOMATIC PROFILE TRIGGER ON SIGNUP
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    -- Insert profile
    INSERT INTO public.profiles (id, email, full_name)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', '')
    );

    -- Insert default Free subscription
    INSERT INTO public.subscriptions (user_id, tier, status)
    VALUES (NEW.id, 'free', 'active');

    -- Insert initial Free usage quota (5 CVs)
    INSERT INTO public.usage_quotas (user_id, evaluations_used, evaluations_limit)
    VALUES (NEW.id, 0, 5);

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger firing after user registers in auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
