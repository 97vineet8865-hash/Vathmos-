import React, { useState, useEffect } from 'react';
import {
  X,
  LogOut,
  Check,
  Building2,
  Briefcase,
  Mail,
  Calendar,
  ShieldCheck,
  Award,
  Edit2,
  Save,
  Bot,
  Send,
  Sparkles,
  Bug,
  MessageSquare,
  Loader2,
  ChevronDown,
  Inbox,
  Trash2,
  ExternalLink,
  CheckCircle2,
  Clock,
  AlertCircle,
  ArrowUpRight,
  Settings,
  RefreshCw,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { CandidateItem, FeedbackItem } from '../types';

interface ProfileModalProps {
  candidates?: CandidateItem[];
  jobDescription?: string;
}

const COLOR_OPTIONS = [
  '#6366F1', // Indigo
  '#10B981', // Emerald
  '#0EA5E9', // Sky Blue
  '#8B5CF6', // Purple
  '#EC4899', // Pink
  '#F59E0B', // Amber
];

const ADMIN_EMAILS = ['vathmossupport@gmail.com', '97.vineet.8865@gmail.com'];

export const ProfileModal: React.FC<ProfileModalProps> = ({
  candidates = [],
  jobDescription = '',
}) => {
  const { currentUser, isProfileModalOpen, closeProfileModal, updateProfile, signOut, openAuthModal } =
    useAuth();

  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(currentUser?.name || '');
  const [companyName, setCompanyName] = useState(currentUser?.companyName || '');
  const [role, setRole] = useState(currentUser?.role || '');
  const [selectedColor, setSelectedColor] = useState(currentUser?.avatarColor || '#6366F1');

  // Co-Pilot & Support states
  const [activeTab, setActiveTab] = useState<'copilot' | 'feedback' | 'admin'>('copilot');
  const [copilotQuery, setCopilotQuery] = useState('');
  const [copilotLoading, setCopilotLoading] = useState(false);
  const [copilotMessages, setCopilotMessages] = useState<
    Array<{ role: 'user' | 'assistant'; text: string }>
  >([
    {
      role: 'assistant',
      text: 'Hi! I am your Vathmos Recruiter Co-Pilot. Ask me to compare candidates, draft tailored interview emails, explain rubric scores, or report any feedback.',
    },
  ]);

  // Feedback Submission State
  const [feedbackType, setFeedbackType] = useState<'bug' | 'feature' | 'general'>('bug');
  const [feedbackText, setFeedbackText] = useState('');
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);
  const [feedbackLoading, setFeedbackLoading] = useState(false);
  const [lastRefId, setLastRefId] = useState<string | null>(null);

  // Admin Feedback Management State
  const [adminReports, setAdminReports] = useState<FeedbackItem[]>([]);
  const [adminLoading, setAdminLoading] = useState(false);
  const [adminFilter, setAdminFilter] = useState<'all' | 'bug' | 'feature' | 'general'>('all');
  const [webhookUrlInput, setWebhookUrlInput] = useState('');
  const [hasWebhook, setHasWebhook] = useState(false);
  const [showWebhookConfig, setShowWebhookConfig] = useState(false);
  const [webhookSaving, setWebhookSaving] = useState(false);
  const [webhookStatusNotice, setWebhookStatusNotice] = useState<string | null>(null);

  const isAdmin = currentUser?.email && ADMIN_EMAILS.includes(currentUser.email.toLowerCase());

  // Fetch feedback records from server
  const loadReports = async () => {
    setAdminLoading(true);
    try {
      const res = await fetch('/api/feedback', {
        headers: {
          'x-admin-email': currentUser?.email || '',
        },
      });
      if (res.ok) {
        const data = await res.json();
        setAdminReports(data.feedbacks || []);
        setHasWebhook(Boolean(data.hasWebhook));
        if (data.webhookUrl) {
          setWebhookUrlInput(data.webhookUrl);
        }
      }
    } catch (err) {
      console.error('Failed to load feedback reports:', err);
    } finally {
      setAdminLoading(false);
    }
  };

  useEffect(() => {
    if (currentUser) {
      setName(currentUser.name);
      setCompanyName(currentUser.companyName);
      setRole(currentUser.role);
      setSelectedColor(currentUser.avatarColor);
    }
  }, [currentUser, isProfileModalOpen]);

  useEffect(() => {
    if (isProfileModalOpen && isAdmin) {
      loadReports();
    }
  }, [isProfileModalOpen, isAdmin]);

  if (!isProfileModalOpen || !currentUser) return null;

  // Calculate live user session stats
  const completedCandidates = candidates.filter((c) => c.status === 'completed' && c.result);
  const totalEvaluated = completedCandidates.length;
  const topMatches = completedCandidates.filter((c) => (c.result?.score || 0) >= 85).length;
  const averageScore =
    totalEvaluated > 0
      ? Math.round(
          completedCandidates.reduce((sum, c) => sum + (c.result?.score || 0), 0) /
            totalEvaluated
        )
      : null;

  const newReportsCount = adminReports.filter((r) => r.status === 'new').length;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name: name.trim() || currentUser.name,
      companyName: companyName.trim() || currentUser.companyName,
      role: role.trim() || currentUser.role,
      avatarColor: selectedColor,
    });
    setIsEditing(false);
  };

  const handleSendCopilot = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const q = copilotQuery.trim();
    if (!q || copilotLoading) return;

    setCopilotMessages((prev) => [...prev, { role: 'user', text: q }]);
    setCopilotQuery('');
    setCopilotLoading(true);

    try {
      const candidatesSummary = completedCandidates.map((c) => ({
        name: c.name,
        score: c.result?.score,
        recommendation: c.result?.recommendation,
        matched_skills: c.result?.matched_skills,
        missing_skills: c.result?.missing_skills,
        pros: c.result?.pros,
        cons: c.result?.cons,
        rank_reasoning: c.result?.rank_reasoning,
      }));

      const res = await fetch('/api/assistant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: q,
          jobDescription,
          candidatesSummary,
        }),
      });

      const data = await res.json();
      setCopilotMessages((prev) => [
        ...prev,
        { role: 'assistant', text: data.reply || 'Analysis completed.' },
      ]);
    } catch (err) {
      setCopilotMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: 'Sorry, I encountered a temporary connection issue. Please try again.',
        },
      ]);
    } finally {
      setCopilotLoading(false);
    }
  };

  const handleSendFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackText.trim() || feedbackLoading) return;

    setFeedbackLoading(true);
    try {
      const res = await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: feedbackType,
          description: feedbackText.trim(),
          email: currentUser.email,
          name: currentUser.name,
          telemetry: {
            userAgent: navigator.userAgent,
            evaluatedCandidatesCount: totalEvaluated,
            activeRole: currentUser.role,
          },
        }),
      });
      const data = await res.json();
      setLastRefId(data.referenceId || `FB-${Date.now().toString(36).toUpperCase()}`);
      setFeedbackSubmitted(true);
      setFeedbackText('');
      if (isAdmin) {
        loadReports();
      }
    } catch (err) {
      console.log('Feedback error:', err);
    } finally {
      setFeedbackLoading(false);
    }
  };

  const handleUpdateStatus = async (
    id: string,
    status: 'new' | 'investigating' | 'resolved'
  ) => {
    try {
      const res = await fetch(`/api/feedback/${id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-email': currentUser?.email || '',
        },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        setAdminReports((prev) =>
          prev.map((item) => (item.id === id ? { ...item, status } : item))
        );
      }
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };

  const handleDeleteReport = async (id: string) => {
    try {
      const res = await fetch(`/api/feedback/${id}`, {
        method: 'DELETE',
        headers: {
          'x-admin-email': currentUser?.email || '',
        },
      });
      if (res.ok) {
        setAdminReports((prev) => prev.filter((item) => item.id !== id));
      }
    } catch (err) {
      console.error('Failed to delete report:', err);
    }
  };

  const handleSaveWebhook = async () => {
    setWebhookSaving(true);
    setWebhookStatusNotice(null);
    try {
      const res = await fetch('/api/feedback/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-email': currentUser?.email || '',
        },
        body: JSON.stringify({ webhookUrl: webhookUrlInput.trim() }),
      });
      if (res.ok) {
        setHasWebhook(Boolean(webhookUrlInput.trim()));
        setWebhookStatusNotice('Webhook destination saved successfully!');
      } else {
        setWebhookStatusNotice('Failed to save webhook URL.');
      }
    } catch {
      setWebhookStatusNotice('Network error saving webhook.');
    } finally {
      setWebhookSaving(false);
    }
  };

  const handleTestWebhook = async () => {
    setWebhookStatusNotice('Sending test alert to webhook...');
    try {
      const res = await fetch('/api/feedback/test-webhook', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-email': currentUser?.email || '',
        },
        body: JSON.stringify({ webhookUrl: webhookUrlInput.trim() }),
      });
      const data = await res.json();
      if (res.ok) {
        setWebhookStatusNotice('Test notification received successfully on webhook!');
      } else {
        setWebhookStatusNotice(`Test alert failed: ${data.error || 'Check webhook URL'}`);
      }
    } catch {
      setWebhookStatusNotice('Network error dispatching test.');
    }
  };

  const getInitials = (n: string) => {
    return n
      .split(' ')
      .map((part) => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const filteredAdminReports = adminReports.filter((r) => {
    if (adminFilter === 'all') return true;
    return r.type === adminFilter;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div
        id="user-profile-modal-card"
        className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto bg-[#12151E]/95 backdrop-blur-2xl border border-white/[0.08] rounded-2xl shadow-2xl p-6 sm:p-7 text-zinc-100"
      >
        {/* Close button */}
        <button
          type="button"
          onClick={closeProfileModal}
          className="absolute top-4 right-4 p-1.5 rounded-xl text-zinc-400 hover:text-white hover:bg-white/[0.05] transition-colors cursor-pointer"
          aria-label="Close profile modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Profile Card Header */}
        <div className="flex items-start gap-4 mb-6 pb-6 border-b border-white/[0.06]">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center text-xl font-bold text-white shadow-md border border-white/10 shrink-0"
            style={{ backgroundColor: isEditing ? selectedColor : currentUser.avatarColor }}
          >
            {getInitials(isEditing ? name : currentUser.name)}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight text-white truncate">
                {currentUser.name}
              </h2>
              {isAdmin ? (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[10px] font-semibold bg-blue-500/15 text-blue-300 border border-blue-500/30 shrink-0">
                  <ShieldCheck className="w-3 h-3" />
                  <span>Platform Admin</span>
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md text-[10px] font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shrink-0">
                  <ShieldCheck className="w-3 h-3" />
                  <span>Verified</span>
                </span>
              )}
            </div>
            <p className="text-xs text-zinc-400 mt-0.5 truncate">{currentUser.email}</p>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-2 text-xs text-zinc-400">
              <span className="inline-flex items-center gap-1">
                <Building2 className="w-3.5 h-3.5 text-zinc-500" />
                <span className="text-zinc-300">{currentUser.companyName}</span>
              </span>
              <span className="inline-flex items-center gap-1">
                <Briefcase className="w-3.5 h-3.5 text-zinc-500" />
                <span className="text-zinc-300">{currentUser.role}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Recruiter Workspace Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="p-3 bg-[#0E1018]/80 border border-white/[0.06] rounded-xl text-center">
            <p className="text-[11px] font-medium text-zinc-400">Evaluations</p>
            <p className="text-lg font-bold text-white mt-0.5 font-mono">{totalEvaluated}</p>
          </div>
          <div className="p-3 bg-[#0E1018]/80 border border-white/[0.06] rounded-xl text-center">
            <p className="text-[11px] font-medium text-zinc-400">Top Matches</p>
            <p className="text-lg font-bold text-emerald-400 mt-0.5 font-mono">{topMatches}</p>
          </div>
          <div className="p-3 bg-[#0E1018]/80 border border-white/[0.06] rounded-xl text-center">
            <p className="text-[11px] font-medium text-zinc-400">Avg Score</p>
            <p className="text-lg font-bold text-sky-400 mt-0.5 font-mono">
              {averageScore !== null ? `${averageScore}/100` : '—'}
            </p>
          </div>
        </div>

        {/* Profile Info / Edit Section */}
        {isEditing ? (
          <form onSubmit={handleSave} className="space-y-3.5 mb-6">
            <div>
              <label className="block text-xs font-medium text-[#A1A1AA] mb-1">
                Full Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 bg-[#121214] border border-[#27272A] focus:border-[#6366F1] rounded-lg text-sm text-[#FAFAFA] focus:outline-hidden transition-colors"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-[#A1A1AA] mb-1">
                  Company Name
                </label>
                <input
                  type="text"
                  required
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#121214] border border-[#27272A] focus:border-[#6366F1] rounded-lg text-sm text-[#FAFAFA] focus:outline-hidden transition-colors"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#A1A1AA] mb-1">
                  Recruiter Role
                </label>
                <input
                  type="text"
                  required
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full px-3 py-2 bg-[#121214] border border-[#27272A] focus:border-[#6366F1] rounded-lg text-sm text-[#FAFAFA] focus:outline-hidden transition-colors"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#A1A1AA] mb-1.5">
                Avatar Accent Color
              </label>
              <div className="flex items-center gap-2">
                {COLOR_OPTIONS.map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setSelectedColor(color)}
                    className={`w-7 h-7 rounded-lg transition-transform cursor-pointer flex items-center justify-center ${
                      selectedColor === color ? 'scale-110 ring-2 ring-white' : 'opacity-80 hover:opacity-100'
                    }`}
                    style={{ backgroundColor: color }}
                  >
                    {selectedColor === color && <Check className="w-4 h-4 text-white" />}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium text-[#A1A1AA] hover:text-[#FAFAFA] hover:bg-[#27272A] transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold bg-[#6366F1] hover:bg-[#4F46E5] text-white shadow-xs transition-colors cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>Save Changes</span>
              </button>
            </div>
          </form>
        ) : (
          <div className="space-y-3 mb-6 bg-[#121214] border border-[#27272A] rounded-xl p-4 text-xs">
            <div className="flex items-center justify-between py-1 border-b border-[#27272A]/60">
              <span className="text-[#71717A]">Member Since</span>
              <span className="text-[#D4D4D8] font-medium inline-flex items-center gap-1">
                <Calendar className="w-3 h-3 text-[#A1A1AA]" />
                <span>{currentUser.joinedAt}</span>
              </span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-[#27272A]/60">
              <span className="text-[#71717A]">Active Role</span>
              <span className="text-[#D4D4D8] font-medium">{currentUser.role}</span>
            </div>
            <div className="flex items-center justify-between py-1 border-b border-[#27272A]/60">
              <span className="text-[#71717A]">Organization</span>
              <span className="text-[#D4D4D8] font-medium">{currentUser.companyName}</span>
            </div>
            <div className="flex items-center justify-between py-1">
              <span className="text-[#71717A]">Rubric System</span>
              <span className="text-[#818CF8] font-medium inline-flex items-center gap-1">
                <Award className="w-3 h-3" />
                <span>100-Point Standard</span>
              </span>
            </div>
          </div>
        )}

        {/* ============================================================== */}
        {/* SCROLL DOWN SECTION: RECRUITER CO-PILOT & SUPPORT DESK         */}
        {/* ============================================================== */}
        <div className="bg-[#121214] border border-[#27272A] rounded-xl p-4 space-y-3 mb-6">
          {/* Tab selector */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#27272A] pb-3">
            <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('copilot')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                  activeTab === 'copilot'
                    ? 'bg-[#6366F1] text-white shadow-xs'
                    : 'text-[#A1A1AA] hover:text-[#FAFAFA] bg-[#18181B]'
                }`}
              >
                <Bot className="w-3.5 h-3.5" />
                <span>AI Co-Pilot</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('feedback')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                  activeTab === 'feedback'
                    ? 'bg-[#27272A] text-[#FAFAFA] border border-[#3F3F46]'
                    : 'text-[#A1A1AA] hover:text-[#FAFAFA] bg-[#18181B]'
                }`}
              >
                <Bug className="w-3.5 h-3.5 text-amber-400" />
                <span>Report Issue / Idea</span>
              </button>

              {isAdmin && (
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('admin');
                    loadReports();
                  }}
                  className={`relative inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer transition-colors ${
                    activeTab === 'admin'
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                      : 'text-[#A1A1AA] hover:text-[#FAFAFA] bg-[#18181B]'
                  }`}
                >
                  <Inbox className="w-3.5 h-3.5 text-rose-400" />
                  <span>Admin Inbox</span>
                  {newReportsCount > 0 && (
                    <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-rose-500 text-white">
                      {newReportsCount}
                    </span>
                  )}
                </button>
              )}
            </div>
            <span className="text-[10px] text-[#71717A] font-mono">
              {activeTab === 'copilot'
                ? 'Live Workspace AI'
                : activeTab === 'feedback'
                ? 'Direct Feedback'
                : 'Dev Center'}
            </span>
          </div>

          {/* TAB 1: CO-PILOT CHAT */}
          {activeTab === 'copilot' && (
            <div className="space-y-3">
              <div className="max-h-48 overflow-y-auto space-y-2 p-2 rounded-lg bg-[#18181B] border border-[#27272A]/70 text-xs">
                {copilotMessages.map((msg, i) => (
                  <div
                    key={i}
                    className={`p-2.5 rounded-lg leading-relaxed ${
                      msg.role === 'user'
                        ? 'bg-[#6366F1]/20 text-[#FAFAFA] ml-4 border border-[#6366F1]/30'
                        : 'bg-[#27272A]/60 text-[#D4D4D8] mr-4 border border-[#27272A]'
                    }`}
                  >
                    <div className="text-[10px] font-mono text-[#A1A1AA] mb-1 flex items-center gap-1">
                      {msg.role === 'user' ? 'You' : 'Vathmos Co-Pilot'}
                    </div>
                    <p className="whitespace-pre-wrap">{msg.text}</p>
                  </div>
                ))}
                {copilotLoading && (
                  <div className="flex items-center gap-2 p-2 text-xs text-[#818CF8]">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Thinking with current candidates...</span>
                  </div>
                )}
              </div>

              {/* Quick Prompts */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
                <button
                  type="button"
                  onClick={() => {
                    setCopilotQuery('Compare top candidates side-by-side');
                  }}
                  className="px-2 py-1 rounded bg-[#27272A] hover:bg-[#3F3F46] text-[#A1A1AA] hover:text-white shrink-0 cursor-pointer transition-colors"
                >
                  Compare candidates
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCopilotQuery('Draft interview invite email for our top candidate');
                  }}
                  className="px-2 py-1 rounded bg-[#27272A] hover:bg-[#3F3F46] text-[#A1A1AA] hover:text-white shrink-0 cursor-pointer transition-colors"
                >
                  Draft interview invite
                </button>
              </div>

              {/* Query Input */}
              <form onSubmit={handleSendCopilot} className="flex items-center gap-2">
                <input
                  type="text"
                  value={copilotQuery}
                  onChange={(e) => setCopilotQuery(e.target.value)}
                  placeholder="Ask co-pilot (e.g. why did candidate 1 win?)..."
                  className="flex-1 px-3 py-1.5 rounded-lg bg-[#18181B] border border-[#27272A] text-xs text-white focus:outline-hidden focus:border-[#6366F1]"
                />
                <button
                  type="submit"
                  disabled={!copilotQuery.trim() || copilotLoading}
                  className="p-2 rounded-lg bg-[#6366F1] hover:bg-[#4F46E5] disabled:opacity-50 text-white cursor-pointer transition-colors"
                  aria-label="Send query"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          )}

          {/* TAB 2: BUG REPORT & FEEDBACK SUBMISSION */}
          {activeTab === 'feedback' && (
            <form onSubmit={handleSendFeedback} className="space-y-3 text-xs">
              {feedbackSubmitted ? (
                <div className="p-3.5 rounded-xl bg-[#10B981]/15 border border-[#10B981]/30 text-[#34D399] space-y-2">
                  <div className="flex items-center gap-2 justify-center font-semibold text-sm">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Report Logged Successfully!</span>
                  </div>
                  <p className="text-[11px] text-[#D4D4D8] text-center">
                    Saved to persistent developer inbox under reference{' '}
                    <span className="font-mono font-bold text-white bg-[#18181B] px-1.5 py-0.5 rounded border border-[#27272A]">
                      #{lastRefId || 'FB-LOG'}
                    </span>
                  </p>
                  <p className="text-[10px] text-[#A1A1AA] text-center">
                    Our engineering team reviews diagnostics and PDF parsing telemetry continuously.
                  </p>

                  <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-2">
                    <a
                      href={`mailto:vathmossupport@gmail.com?subject=Vathmos%20Report%20%5B${
                        lastRefId || 'FEEDBACK'
                      }%5D&body=Hello%20Vathmos%20Team%2C%0A%0AI%20submitted%20a%20report%20via%20Vathmos%20(Ref%3A%20${
                        lastRefId || 'FB'
                      }).%0A%0AUser%3A%20${encodeURIComponent(
                        currentUser.name
                      )}%20(${encodeURIComponent(currentUser.email)})%0A`}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#6366F1] hover:bg-[#4F46E5] text-white text-xs font-semibold cursor-pointer transition-colors"
                    >
                      <Mail className="w-3.5 h-3.5" />
                      <span>Email Support Desk</span>
                      <ArrowUpRight className="w-3 h-3" />
                    </a>
                    <button
                      type="button"
                      onClick={() => setFeedbackSubmitted(false)}
                      className="text-xs text-[#A1A1AA] hover:text-white underline cursor-pointer"
                    >
                      Submit another note
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <label className="text-[#A1A1AA] text-[11px]">Category:</label>
                      <select
                        value={feedbackType}
                        onChange={(e) => setFeedbackType(e.target.value as any)}
                        className="px-2 py-1 rounded bg-[#18181B] border border-[#27272A] text-xs text-white"
                      >
                        <option value="bug">🐛 Bug / PDF Parsing Snag</option>
                        <option value="feature">💡 Feature Request</option>
                        <option value="general">💬 General Feedback</option>
                      </select>
                    </div>
                    <span className="text-[10px] text-[#71717A]">
                      Logged to developer database
                    </span>
                  </div>

                  <textarea
                    rows={3}
                    value={feedbackText}
                    onChange={(e) => setFeedbackText(e.target.value)}
                    placeholder="Describe what happened, the candidate file format, or feature you would love to see..."
                    className="w-full p-2.5 rounded-lg bg-[#18181B] border border-[#27272A] text-xs text-white focus:outline-hidden focus:border-[#6366F1] resize-none"
                    required
                  />

                  <div className="flex items-center justify-between text-[11px] text-[#71717A]">
                    <span>Includes browser & session telemetry</span>
                    <button
                      type="submit"
                      disabled={!feedbackText.trim() || feedbackLoading}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#6366F1] hover:bg-[#4F46E5] disabled:opacity-50 text-white font-semibold cursor-pointer transition-colors"
                    >
                      {feedbackLoading ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Saving...</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-3.5 h-3.5" />
                          <span>Submit Report</span>
                        </>
                      )}
                    </button>
                  </div>
                </>
              )}
            </form>
          )}

          {/* TAB 3: ADMIN INBOX (Only visible to vathmossupport@gmail.com) */}
          {activeTab === 'admin' && isAdmin && (
            <div className="space-y-3 text-xs">
              {/* Header and Refresh */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="font-semibold text-white">User Reports Feed</span>
                  <span className="text-[#71717A]">({adminReports.length} total)</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setShowWebhookConfig(!showWebhookConfig)}
                    className="inline-flex items-center gap-1 text-[11px] text-[#A1A1AA] hover:text-[#FAFAFA] cursor-pointer"
                  >
                    <Settings className="w-3 h-3" />
                    <span>Webhook</span>
                  </button>
                  <button
                    type="button"
                    onClick={loadReports}
                    disabled={adminLoading}
                    className="p-1 rounded text-[#A1A1AA] hover:text-white hover:bg-[#27272A] cursor-pointer"
                    title="Refresh reports"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${adminLoading ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>

              {/* Webhook Configuration Drawer */}
              {showWebhookConfig && (
                <div className="p-3 bg-[#18181B] border border-[#27272A] rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <p className="font-semibold text-white text-[11px]">
                      🔔 Instant Webhook Notifications (Discord / Telegram / Slack)
                    </p>
                    {hasWebhook && (
                      <span className="text-[10px] text-emerald-400 font-medium">● Connected</span>
                    )}
                  </div>
                  <p className="text-[10px] text-[#A1A1AA]">
                    Paste your Discord, Slack, or Telegram bot URL here. Whenever any recruiter submits a contact request, bug, or idea, your channel gets pinged immediately!
                  </p>
                  <div className="flex items-center gap-2">
                    <input
                      type="url"
                      value={webhookUrlInput}
                      onChange={(e) => setWebhookUrlInput(e.target.value)}
                      placeholder="Discord, Slack, or https://api.telegram.org/bot<TOKEN>/sendMessage?chat_id=<ID>"
                      className="flex-1 px-2.5 py-1.5 rounded-lg bg-[#121214] border border-[#27272A] text-xs text-white focus:outline-hidden focus:border-[#6366F1]"
                    />
                    <button
                      type="button"
                      onClick={handleSaveWebhook}
                      disabled={webhookSaving}
                      className="px-3 py-1.5 rounded-lg bg-[#27272A] hover:bg-[#3F3F46] text-white text-xs font-medium cursor-pointer"
                    >
                      {webhookSaving ? 'Saving...' : 'Save'}
                    </button>
                    <button
                      type="button"
                      onClick={handleTestWebhook}
                      className="px-3 py-1.5 rounded-lg bg-[#6366F1] hover:bg-[#4F46E5] text-white text-xs font-semibold cursor-pointer"
                    >
                      Test
                    </button>
                  </div>
                  {webhookStatusNotice && (
                    <p className="text-[11px] text-[#818CF8]">{webhookStatusNotice}</p>
                  )}
                </div>
              )}

              {/* Filter Tabs */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px]">
                {(['all', 'bug', 'feature', 'general'] as const).map((filterKey) => (
                  <button
                    key={filterKey}
                    type="button"
                    onClick={() => setAdminFilter(filterKey)}
                    className={`px-2 py-0.5 rounded-md cursor-pointer transition-colors capitalize ${
                      adminFilter === filterKey
                        ? 'bg-[#6366F1] text-white font-semibold'
                        : 'bg-[#18181B] text-[#A1A1AA] hover:text-white'
                    }`}
                  >
                    {filterKey === 'all'
                      ? `All (${adminReports.length})`
                      : filterKey === 'bug'
                      ? `🐛 Bugs (${adminReports.filter((r) => r.type === 'bug').length})`
                      : filterKey === 'feature'
                      ? `💡 Ideas (${adminReports.filter((r) => r.type === 'feature').length})`
                      : `💬 Notes (${adminReports.filter((r) => r.type === 'general').length})`}
                  </button>
                ))}
              </div>

              {/* Reports List */}
              <div className="max-h-56 overflow-y-auto space-y-2 pr-1">
                {adminLoading ? (
                  <div className="flex items-center justify-center p-6 text-[#A1A1AA]">
                    <Loader2 className="w-4 h-4 animate-spin mr-2" />
                    <span>Loading reports...</span>
                  </div>
                ) : filteredAdminReports.length === 0 ? (
                  <div className="p-6 text-center text-[#71717A] bg-[#18181B] rounded-xl border border-[#27272A]">
                    <Inbox className="w-6 h-6 mx-auto mb-1 text-[#3F3F46]" />
                    <p>No user reports in this category yet.</p>
                  </div>
                ) : (
                  filteredAdminReports.map((report) => (
                    <div
                      key={report.id}
                      className="p-3 rounded-xl bg-[#18181B] border border-[#27272A] space-y-2 text-xs"
                    >
                      {/* Top Row */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                              report.type === 'bug'
                                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                                : report.type === 'feature'
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                            }`}
                          >
                            {report.type === 'bug'
                              ? '🐛 Bug'
                              : report.type === 'feature'
                              ? '💡 Feature'
                              : '💬 Note'}
                          </span>
                          <span className="font-mono text-[10px] text-[#A1A1AA]">
                            #{report.id}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-medium capitalize ${
                              report.status === 'resolved'
                                ? 'bg-emerald-500/20 text-emerald-300'
                                : report.status === 'investigating'
                                ? 'bg-amber-500/20 text-amber-300'
                                : 'bg-rose-500/20 text-rose-300'
                            }`}
                          >
                            {report.status}
                          </span>
                          <span className="text-[10px] text-[#71717A]">
                            {new Date(report.createdAt).toLocaleDateString(undefined, {
                              month: 'short',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                        </div>
                      </div>

                      {/* Description */}
                      <p className="text-[#FAFAFA] whitespace-pre-wrap leading-relaxed bg-[#121214] p-2 rounded-lg border border-[#27272A]/60">
                        {report.description}
                      </p>

                      {/* User & Telemetry details */}
                      <div className="flex flex-wrap items-center justify-between gap-2 text-[10px] text-[#71717A]">
                        <div>
                          <span className="text-[#D4D4D8] font-medium">
                            {report.userName}
                          </span>{' '}
                          ({report.userEmail})
                          {report.telemetry?.evaluatedCandidatesCount !== undefined && (
                            <span className="ml-2 text-[#818CF8]">
                              • {report.telemetry.evaluatedCandidatesCount} resumes tested
                            </span>
                          )}
                        </div>

                        {/* Actions */}
                        <div className="flex items-center gap-1.5">
                          <select
                            value={report.status}
                            onChange={(e) =>
                              handleUpdateStatus(report.id, e.target.value as any)
                            }
                            className="bg-[#121214] border border-[#27272A] rounded px-1.5 py-0.5 text-[10px] text-white cursor-pointer"
                          >
                            <option value="new">New</option>
                            <option value="investigating">Investigating</option>
                            <option value="resolved">Resolved</option>
                          </select>

                          {report.userEmail && report.userEmail !== 'Anonymous' && (
                            <a
                              href={`mailto:${report.userEmail}?subject=Vathmos%20Update%20on%20%5B${report.id}%5D&body=Hi%20${encodeURIComponent(
                                report.userName
                              )}%2C%0A%0AThank%20you%20for%20your%20report%20regarding%3A%0A%22${encodeURIComponent(
                                report.description.slice(0, 100)
                              )}%22...%0A`}
                              className="p-1 rounded text-[#A1A1AA] hover:text-[#FAFAFA] hover:bg-[#27272A]"
                              title="Reply via Email"
                            >
                              <Mail className="w-3.5 h-3.5" />
                            </a>
                          )}

                          <button
                            type="button"
                            onClick={() => handleDeleteReport(report.id)}
                            className="p-1 rounded text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 cursor-pointer"
                            title="Delete record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center justify-between pt-2 border-t border-[#27272A]">
          {!isEditing ? (
            <button
              type="button"
              onClick={() => setIsEditing(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-[#FAFAFA] bg-[#27272A] hover:bg-[#3F3F46] border border-[#3F3F46] transition-colors cursor-pointer"
            >
              <Edit2 className="w-3.5 h-3.5 text-[#A1A1AA]" />
              <span>Edit Profile</span>
            </button>
          ) : (
            <div />
          )}

          <button
            type="button"
            onClick={signOut}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 border border-rose-500/20 transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>
    </div>
  );
};
