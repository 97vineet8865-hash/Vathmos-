import React from 'react';
import { Shield, Lock, EyeOff, ServerOff, FileCheck2, ArrowLeft, ArrowUpRight, CheckCircle2, AlertTriangle, Mail } from 'lucide-react';
import { Link, useRouter } from '../router/RouterContext';

export const PrivacyPolicyPage: React.FC = () => {
  const { navigate } = useRouter();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-white">
      {/* Top Navigation Bar */}
      <header className="border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/')}
              className="flex items-center gap-2 text-slate-400 hover:text-white text-xs font-semibold py-1.5 px-3 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Home</span>
            </button>
            <div className="h-4 w-px bg-slate-800" />
            <div className="flex items-center gap-2">
              <span className="text-base font-bold tracking-tight text-white">Vathmos</span>
              <span className="text-xs text-slate-400">/ Legal & Compliance</span>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <Link
              href="/dashboard"
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white text-xs font-bold shadow-md hover:from-sky-400 hover:to-indigo-500 transition cursor-pointer"
            >
              <span>Launch App</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-4xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 space-y-10">
        {/* Header Hero */}
        <div className="space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Shield className="w-3.5 h-3.5" />
            <span>Effective Date: October 12, 2026 • Version 2.4</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
            Privacy Policy & Candidate Data Protection Charter
          </h1>
          <p className="text-sm sm:text-base text-slate-400 leading-relaxed">
            At Vathmos (<span className="text-slate-200">Vathmos Technologies</span>), candidate privacy and enterprise security are not retroactive add-ons—they are engineered into our foundational runtime architecture. This policy details our strict <strong className="text-white">Zero Data Retention (ZDR)</strong> framework, transient memory parsing, and AI model isolation.
          </p>
        </div>

        {/* Core Pillars Highlights Box */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <ServerOff className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white">Zero Data Retention</h3>
            <p className="text-xs text-slate-400 leading-normal">
              Candidate resumes exist only in volatile server memory (RAM) during calculation and are instantly flushed upon completion.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-sky-500/10 border border-sky-500/20 text-sky-400 flex items-center justify-center">
              <EyeOff className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white">Non-Training AI Policy</h3>
            <p className="text-xs text-slate-400 leading-normal">
              Candidate documents and recruiter job specifications are never utilized to train, tune, or improve foundational AI models.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800/80 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center">
              <FileCheck2 className="w-4 h-4" />
            </div>
            <h3 className="text-sm font-bold text-white">GDPR & DPDP Act Ready</h3>
            <p className="text-xs text-slate-400 leading-normal">
              Architecture fully compliant with GDPR Article 17 (Right to Erasure) and Article 22 (Human-in-the-Loop decision governance).
            </p>
          </div>
        </div>

        {/* Detailed Sections */}
        <div className="space-y-8 text-sm leading-relaxed text-slate-300">
          {/* Section 1 */}
          <section className="space-y-3 p-6 rounded-2xl bg-slate-900/40 border border-slate-800/60">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <span className="text-cyan-400 font-mono text-sm">01.</span>
              Transient In-Memory Processing Architecture
            </h2>
            <p>
              When a recruiter or hiring manager uploads a candidate resume (PDF, DOCX, or text) to Vathmos:
            </p>
            <ul className="list-disc pl-5 space-y-2 text-slate-400">
              <li>
                <strong className="text-slate-200">Ephemeral Memory Parsing:</strong> The document is converted to text strictly within volatile server RAM buffers. At no point is the PDF file written to a persistent hard disk drive (HDD), solid-state disk (SSD), or permanent object storage (e.g., S3/GCS).
              </li>
              <li>
                <strong className="text-slate-200">Immediate Buffer Flushing:</strong> As soon as the evaluation response payload (the 100-point rubric breakdown) is compiled and transmitted back to the user's browser, the raw text buffer and extraction pointers are immediately garbage-collected and erased from server RAM.
              </li>
              <li>
                <strong className="text-slate-200">Client-Side Persistence:</strong> Candidate evaluation cards, notes, and leaderboard scores remain cached on the client side in the user's local browser storage. The user retains complete ownership and can purge all workspace state at any time via the <em>Reset Workspace</em> command.
              </li>
            </ul>
          </section>

          {/* Section 2 */}
          <section className="space-y-3 p-6 rounded-2xl bg-slate-900/40 border border-slate-800/60">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <span className="text-cyan-400 font-mono text-sm">02.</span>
              Zero AI Model Training Guarantee
            </h2>
            <p>
              We maintain commercial enterprise zero-retention API agreements with foundational model providers (Google Gemini API enterprise tier). Under these binding enterprise terms:
            </p>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <div className="flex items-center gap-2 text-emerald-400 font-semibold">
                <CheckCircle2 className="w-4 h-4" />
                <span>Zero Training Loop Inclusion</span>
              </div>
              <p className="text-slate-400">
                Data sent through the Vathmos evaluation pipeline is explicitly blocked from being logged, ingested, stored, or utilized for generative pre-training, fine-tuning, Reinforcement Learning from Human Feedback (RLHF), or any model evaluation procedures.
              </p>
            </div>
          </section>

          {/* Section 3 */}
          <section className="space-y-3 p-6 rounded-2xl bg-slate-900/40 border border-slate-800/60">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <span className="text-cyan-400 font-mono text-sm">03.</span>
              Data Minimization & What We Collect
            </h2>
            <p>
              To deliver the Vathmos SaaS platform and verify payment transactions, we collect only the minimum required operational data:
            </p>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 font-medium">
                    <th className="py-2.5 px-3">Data Category</th>
                    <th className="py-2.5 px-3">Purpose</th>
                    <th className="py-2.5 px-3">Retention Schedule</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  <tr>
                    <td className="py-2.5 px-3 font-semibold text-white">Recruiter Account Credentials</td>
                    <td className="py-2.5 px-3">User authentication, subscription credit tracking, profile session.</td>
                    <td className="py-2.5 px-3">Duration of active account; deleted upon user account closure request.</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 px-3 font-semibold text-white">Transaction & Billing Metadata</td>
                    <td className="py-2.5 px-3">Payment verification via Razorpay / Lemon Squeezy (Order ID, Amount, Currency).</td>
                    <td className="py-2.5 px-3">Retained as required by statutory financial tax & auditing laws in India.</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 px-3 font-semibold text-white">Candidate Resumes & CVs</td>
                    <td className="py-2.5 px-3">Ephemeral parsing and 100-point rubric qualification against Job Description.</td>
                    <td className="py-2.5 px-3 text-cyan-400 font-semibold">Zero seconds permanent retention (Transient RAM only).</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 px-3 font-semibold text-white">Support & Feedback Logs</td>
                    <td className="py-2.5 px-3">Direct bug resolution, inquiries, and customer grievance redressal.</td>
                    <td className="py-2.5 px-3">30 days post-resolution, or upon user request.</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </section>

          {/* Section 4 */}
          <section className="space-y-4 p-6 rounded-2xl bg-slate-900/40 border border-slate-800/60">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <span className="text-cyan-400 font-mono text-sm">04.</span>
              Detailed GDPR & International Statutory Compliance
            </h2>
            <div className="space-y-4 text-xs text-slate-300">
              {/* Art 17 */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/90 space-y-2">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>GDPR Article 17 — Right to Erasure ("Right to be Forgotten")</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  Under Regulation (EU) 2016/679 (General Data Protection Regulation) Article 17, data subjects maintain the right to obtain the erasure of their personal data without undue delay. Vathmos fulfills and surpasses this standard through <strong>Zero-Persistence Architecture (ZPA)</strong>:
                </p>
                <ul className="list-disc pl-5 space-y-1.5 text-slate-400">
                  <li><strong>Zero Permanent Resume Storage:</strong> Resumes and CVs are never written to disk, databases, or cloud object stores. They exist strictly in volatile RAM buffers during analysis and are discarded immediately upon returning the rubric breakdown.</li>
                  <li><strong>No Residual Indexing or Backups:</strong> Because raw candidate documents are never committed to non-volatile storage, no resume data resides in system snapshots, database backups, or log clusters.</li>
                  <li><strong>Instant Local Purge:</strong> Evaluation cards saved in the recruiter's local browser can be wiped instantly with the "Reset Workspace" button, removing all candidate traces from the device.</li>
                </ul>
              </div>

              {/* Art 22 */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/90 space-y-2">
                <div className="flex items-center gap-2 text-sky-400 font-bold text-sm">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>GDPR Article 22 — Automated Individual Decision-Making & Profiling</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  Article 22 protects individuals from decisions based solely on automated processing, including profiling, which produces legal or similarly significant effects. Vathmos is engineered strictly with <strong>Mandatory Human Oversight ("Human-in-the-Loop")</strong>:
                </p>
                <ul className="list-disc pl-5 space-y-1.5 text-slate-400">
                  <li><strong>Decision-Support Only:</strong> Vathmos is strictly an analytical co-pilot. The software has <em>zero authority</em> to automatically reject, disqualify, hire, or communicate employment outcomes to candidates.</li>
                  <li><strong>Sole Human Accountability:</strong> All hiring actions, candidate progressions, interview invitations, or rejections remain the exclusive prerogative and responsibility of authorized human recruitment personnel.</li>
                  <li><strong>Transparent & Explainable Rubrics:</strong> Every score is backed by citations, verbatim proof excerpts, and breakdown points across Hard Requirements, Domain Architecture, and Verifiable Evidence—preventing "black box" decisions.</li>
                </ul>
              </div>

              {/* AI Non-Training Warranty */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800/90 space-y-2">
                <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Strict AI Non-Training & Intellectual Property Guarantee</span>
                </div>
                <p className="text-slate-300 leading-relaxed">
                  <strong>Absolute Non-Training Warranty:</strong> Resumes, job descriptions, recruiter notes, and candidate personal identifiers processed through Vathmos are <span className="text-white font-semibold">NEVER</span> used to train, retrain, fine-tune, or adapt foundational AI models, neural networks, or LLMs. We utilize enterprise-grade API endpoints governed by zero-data-retention and zero-training legal commitments.
                </p>
              </div>

              {/* DPDP Act */}
              <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 text-slate-400">
                <strong className="text-slate-200">Digital Personal Data Protection Act (DPDP Act, India 2023):</strong> Vathmos enforces full data fiduciary duties, purpose limitation, and data minimization. Candidate resumes are processed strictly for the requested screening session and immediately flushed.
              </div>
            </div>
          </section>

          {/* Section 5 */}
          <section className="space-y-3 p-6 rounded-2xl bg-slate-900/40 border border-slate-800/60">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <span className="text-cyan-400 font-mono text-sm">05.</span>
              Data Protection Officer & Privacy Inquiries
            </h2>
            <p className="text-xs text-slate-400">
              For any questions regarding this Privacy Policy, your rights under data privacy laws, or to exercise your rights of access or deletion regarding your recruiter profile, please contact our Data Protection desk:
            </p>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="space-y-1">
                <p className="font-bold text-white">Vathmos Data Protection & Compliance Office</p>
                <p className="text-slate-400">Vathmos Technologies • India</p>
                <p className="text-cyan-400 font-mono flex items-center gap-1.5 pt-1">
                  <Mail className="w-3.5 h-3.5" />
                  <span>vathmossupport@gmail.com</span>
                </p>
              </div>
              <Link
                href="/contact"
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-200 font-semibold border border-slate-700 transition"
              >
                <span>Contact Desk</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </section>
        </div>

        {/* Legal Links Footer */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-4 flex-wrap">
            <Link href="/terms" className="hover:text-slate-300 transition">Terms of Service</Link>
            <span>•</span>
            <Link href="/refund" className="hover:text-slate-300 transition">Refund & Cancellation Policy</Link>
            <span>•</span>
            <Link href="/contact" className="hover:text-slate-300 transition">Contact Us</Link>
          </div>
          <p>© {new Date().getFullYear()} Vathmos Technologies. All rights reserved.</p>
        </div>
      </main>
    </div>
  );
};
