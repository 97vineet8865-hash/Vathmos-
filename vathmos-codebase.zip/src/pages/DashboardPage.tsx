import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { Header } from '../components/Header';
import { RubricInfo } from '../components/RubricInfo';
import { JobDescriptionEditor } from '../components/JobDescriptionEditor';
import { ResumeEditor } from '../components/ResumeEditor';
import { ScorecardView } from '../components/ScorecardView';
import { LeaderboardView } from '../components/LeaderboardView';
import { JsonOutputModal } from '../components/JsonOutputModal';
import { SideDrawer } from '../components/SideDrawer';
import { AuthModal } from '../components/AuthModal';
import { ProfileModal } from '../components/ProfileModal';
import { LegalCharterModal } from '../components/LegalCharterModal';
import { CandidateItem, EvaluationResult } from '../types';
import { AlertCircle, Shield, ArrowLeft, ExternalLink, HelpCircle } from 'lucide-react';
import { Link, useRouter } from '../router/RouterContext';

function toTitleCase(str: string): string {
  if (!str) return '';
  // Preserve any disambiguation suffix like (2), (3)
  const suffixMatch = str.match(/\s*(\(\d+\))$/);
  const suffix = suffixMatch ? ` ${suffixMatch[1]}` : '';
  const base = str.replace(/\s*\(\d+\)$/, '').trim();
  const cleaned = base
    .split(/\s+/)
    .map((word) => {
      if (!word) return '';
      if (/^(II|III|IV|VI|VII|VIII|IX|X)$/i.test(word)) return word.toUpperCase();
      return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
    })
    .join(' ');
  return `${cleaned}${suffix}`;
}

function getUniqueCandidateName(
  baseName: string,
  existingCandidates: CandidateItem[],
  excludeId?: string,
  isPlaceholder?: boolean
): string {
  const name = baseName.trim() || 'Candidate';
  const hasCollision = existingCandidates.some(
    (c) =>
      c.id !== excludeId &&
      c.name.trim().toLowerCase() === name.toLowerCase()
  );
  if (!hasCollision) return name;

  // If the base name is a generic placeholder like "Candidate 1" or "Candidate"
  const isGenericCandidate = /^candidate(\s*\d+|\s*\(\d+\))?$/i.test(name);
  if (isGenericCandidate || isPlaceholder) {
    let num = 1;
    let candidateName = `Candidate ${num}`;
    while (
      existingCandidates.some(
        (c) =>
          c.id !== excludeId &&
          c.name.trim().toLowerCase() === candidateName.toLowerCase()
      )
    ) {
      num++;
      candidateName = `Candidate ${num}`;
    }
    return candidateName;
  }

  // Real candidate name (e.g. "Sarah Jenkins" or "Alex Rivera")
  // Strip trailing " (2)" or " (3)"
  const cleanBase = name.replace(/\s*(\(\d+\)|\b\d+)$/, '').trim() || name;
  let counter = 2;
  let candidateName = `${cleanBase} (${counter})`;

  while (
    existingCandidates.some(
      (c) =>
        c.id !== excludeId &&
        c.name.trim().toLowerCase() === candidateName.toLowerCase()
    )
  ) {
    counter++;
    candidateName = `${cleanBase} (${counter})`;
  }
  return candidateName;
}

export const DashboardPage: React.FC = () => {
  const { navigate } = useRouter();
  const [jobDescription, setJobDescription] = useState<string>('');
  const [candidates, setCandidates] = useState<CandidateItem[]>([
    {
      id: 'cand-1',
      name: 'Candidate 1',
      resumeText: '',
      status: 'idle',
    },
  ]);
  const [selectedCandidateId, setSelectedCandidateId] = useState<string>('cand-1');
  const [isEvaluating, setIsEvaluating] = useState<boolean>(false);
  const [isJsonModalOpen, setIsJsonModalOpen] = useState<boolean>(false);
  const [isLegalModalOpen, setIsLegalModalOpen] = useState<boolean>(false);
  const [isSideDrawerOpen, setIsSideDrawerOpen] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [candidateCounter, setCandidateCounter] = useState<number>(2);

  // Side Drawer configurations
  const [minScoreFilter, setMinScoreFilter] = useState<number>(0);
  const [strictnessMode, setStrictnessMode] = useState<'standard' | 'strict' | 'lenient'>(() => {
    try {
      const saved = localStorage.getItem('vathmos_strictness_mode');
      if (saved === 'standard' || saved === 'strict' || saved === 'lenient') {
        return saved;
      }
    } catch {
      // fallback
    }
    return 'standard'; // Default to Standard 100-point balanced rubric
  });

  const handleStrictnessModeChange = (mode: 'standard' | 'strict' | 'lenient') => {
    setStrictnessMode(mode);
    try {
      localStorage.setItem('vathmos_strictness_mode', mode);
    } catch {
      // safe fallback
    }
  };

  const [autoExtractName, setAutoExtractName] = useState<boolean>(true);

  const [batchProgress, setBatchProgress] = useState<{
    current: number;
    total: number;
    name: string;
  } | null>(null);

  const selectedCandidate =
    candidates.find((c) => c.id === selectedCandidateId) || candidates[0];

  const hasAnyData = Boolean(
    jobDescription.trim() || candidates.some((c) => c.resumeText.trim())
  );

  // Trigger celebratory confetti for strong candidates
  const triggerCelebration = () => {
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#4f46e5', '#10b981', '#6366f1', '#3b82f6'],
      });
    } catch {
      // safe fallback
    }
  };

  // Evaluate a specific candidate
  const handleEvaluateCandidate = async (candidateId?: string) => {
    const targetId = candidateId || selectedCandidateId;
    const candidate = candidates.find((c) => c.id === targetId);

    if (!candidate || !jobDescription.trim() || !candidate.resumeText.trim()) {
      return;
    }

    setIsEvaluating(true);
    setErrorMessage(null);

    // Update status to evaluating
    setCandidates((prev) =>
      prev.map((c) => (c.id === targetId ? { ...c, status: 'evaluating' } : c))
    );

    try {
      const response = await fetch('/api/evaluate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jobDescription,
          resumeText: candidate.resumeText,
          candidateName: candidate.name,
          strictnessMode,
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Server error (${response.status})`);
      }

      const result: EvaluationResult = await response.json();

      // Accurately update candidate name if parsed from resume text and not a placeholder
      const rawName = (result.candidate_name || '').trim();
      const isPlaceholder =
        !rawName ||
        ['candidate', 'jane doe', 'john doe', 'alex rivera', 'candidate name', 'unknown'].includes(
          rawName.toLowerCase()
        );
      const chosenName = isPlaceholder ? candidate.name : toTitleCase(rawName);

      setCandidates((prev) => {
        const finalName = getUniqueCandidateName(chosenName, prev, targetId);
        return prev.map((c) =>
          c.id === targetId
            ? {
                ...c,
                name: finalName,
                status: 'completed',
                result,
                error: undefined,
              }
            : c
        );
      });

      if (result.score >= 85) {
        triggerCelebration();
      }
    } catch (err: any) {
      console.error('Evaluation failed:', err);
      let rawMsg = err.message || 'Failed to evaluate candidate.';
      if (rawMsg === 'Failed to fetch' || rawMsg.includes('Failed to fetch') || rawMsg.includes('NetworkError')) {
        rawMsg = 'Server connection temporarily interrupted while starting up. Please click Evaluate again.';
      } else if (rawMsg.toLowerCase().includes('quota') || rawMsg.includes('429') || rawMsg.includes('RESOURCE_EXHAUSTED')) {
        rawMsg = 'Gemini quota limit reached. Please wait a few moments before trying again.';
      }
      setErrorMessage(rawMsg);
      setCandidates((prev) =>
        prev.map((c) =>
          c.id === targetId ? { ...c, status: 'error', error: rawMsg } : c
        )
      );
    } finally {
      setIsEvaluating(false);
    }
  };

  // Progressive Parallel Batch evaluation with real-time per-candidate updates
  const handleEvaluateAll = async () => {
    if (!jobDescription.trim()) return;

    setIsEvaluating(true);
    setErrorMessage(null);

    const targetCandidates = candidates.filter((c) => c.resumeText.trim());
    const totalCount = targetCandidates.length;
    const emptyCount = candidates.length - totalCount;

    if (totalCount === 0) {
      setIsEvaluating(false);
      setErrorMessage('Please add at least one candidate resume before evaluating.');
      return;
    }

    // Set all target candidates to evaluating immediately
    const targetIds = new Set(targetCandidates.map((c) => c.id));
    setCandidates((prev) =>
      prev.map((c) => (targetIds.has(c.id) ? { ...c, status: 'evaluating', error: undefined } : c))
    );

    setBatchProgress({
      current: 0,
      total: totalCount,
      name: `Evaluating 0 of ${totalCount} candidates${emptyCount > 0 ? ` (${emptyCount} empty slot${emptyCount > 1 ? 's' : ''} skipped)` : ''}...`,
    });

    let completedCount = 0;
    let hasTopCandidate = false;

    // Process candidates with high-speed concurrency pool of 2 for fast, fluid evaluation
    try {
      const concurrency = Math.min(2, targetCandidates.length);
      let candidateIndex = 0;

      const runWorker = async () => {
        while (candidateIndex < targetCandidates.length) {
          const currentIdx = candidateIndex++;
          const candidate = targetCandidates[currentIdx];

          setBatchProgress({
            current: completedCount,
            total: totalCount,
            name: `Evaluating candidate ${currentIdx + 1} of ${totalCount}: ${candidate.name}...`,
          });

          try {
            let response: Response | null = null;
            let fetchErr: any = null;

            // Automatic retry with quick backoff on any network hesitation
            for (let attempt = 1; attempt <= 2; attempt++) {
              try {
                response = await fetch('/api/evaluate', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    jobDescription,
                    resumeText: candidate.resumeText,
                    candidateName: candidate.name,
                    strictnessMode,
                  }),
                });
                if (response.ok) break;
              } catch (e) {
                fetchErr = e;
                if (attempt === 1) await new Promise((res) => setTimeout(res, 500));
              }
            }

            if (!response || !response.ok) {
              const errData = response ? await response.json().catch(() => ({})) : {};
              throw new Error(errData.error || fetchErr?.message || `Server error (${response?.status || '500'})`);
            }

            const result: EvaluationResult = await response.json();
            const rawName = (result.candidate_name || '').trim();
            const isPlaceholder =
              !rawName ||
              ['candidate', 'jane doe', 'john doe', 'alex rivera', 'candidate name', 'unknown'].includes(
                rawName.toLowerCase()
              );
            const chosenName = isPlaceholder ? candidate.name : toTitleCase(rawName);

            if (result.score >= 85) {
              hasTopCandidate = true;
            }

            setCandidates((prev) => {
              const finalName = getUniqueCandidateName(chosenName, prev, candidate.id);
              // Ensure candidate_name inside result matches the deduplicated candidate name
              result.candidate_name = finalName;
              return prev.map((c) =>
                c.id === candidate.id
                  ? {
                      ...c,
                      name: finalName,
                      status: 'completed',
                      result,
                      error: undefined,
                    }
                  : c
              );
            });
          } catch (err: any) {
            console.log(`Evaluation error for ${candidate.name}:`, err?.message || err);
            let rawMsg = err.message || 'Evaluation error';
            if (rawMsg === 'Failed to fetch' || rawMsg.includes('Failed to fetch') || rawMsg.includes('NetworkError')) {
              rawMsg = 'Server connection temporarily interrupted. Please click Evaluate again.';
            } else if (
              rawMsg.toLowerCase().includes('quota') ||
              rawMsg.includes('RESOURCE_EXHAUSTED') ||
              rawMsg.includes('429')
            ) {
              rawMsg = 'Gemini quota limit reached. Please wait a moment before retrying.';
            }
            setCandidates((prev) =>
              prev.map((c) =>
                c.id === candidate.id
                  ? { ...c, status: 'error', error: rawMsg }
                  : c
              )
            );
          } finally {
            completedCount++;
            setBatchProgress({
              current: completedCount,
              total: totalCount,
              name: `Evaluated ${completedCount} of ${totalCount} candidates`,
            });
          }
        }
      };

      const workers = Array.from({ length: concurrency }, () => runWorker());
      await Promise.all(workers);

      if (hasTopCandidate) {
        triggerCelebration();
      }

      if (emptyCount > 0) {
        setErrorMessage(`Evaluated all ${totalCount} candidate${totalCount > 1 ? 's' : ''} with resumes. (${emptyCount} empty slot${emptyCount > 1 ? 's were' : ' was'} skipped — paste text or remove slot).`);
      }
    } catch (globalErr: any) {
      console.log('Batch execution error:', globalErr);
      setErrorMessage(globalErr?.message || 'Batch evaluation encountered an issue.');
    } finally {
      setIsEvaluating(false);
      setTimeout(() => {
        setBatchProgress(null);
      }, 1500);
    }
  };

  // Add a single blank candidate
  const handleAddCandidate = () => {
    const newId = `cand-${Date.now()}`;
    setCandidates((prev) => {
      const baseName = `Candidate ${candidateCounter}`;
      const uniqueName = getUniqueCandidateName(baseName, prev, undefined, true);
      const newCandidate: CandidateItem = {
        id: newId,
        name: uniqueName,
        resumeText: '',
        status: 'idle',
      };
      setCandidateCounter((c) => c + 1);
      return [...prev, newCandidate];
    });
    setSelectedCandidateId(newId);
  };

  // Add 10 candidate slots at once
  const handleAdd10Slots = () => {
    setCandidates((prev) => {
      const existingCount = prev.length;
      const targetCount = 10;
      if (existingCount >= targetCount) return prev;
      const countToAdd = targetCount - existingCount;

      const newSlots: CandidateItem[] = [];
      let tempCandidates = [...prev];
      let tempCounter = candidateCounter;

      for (let i = 0; i < countToAdd; i++) {
        const baseName = `Candidate ${tempCounter}`;
        const uniqueName = getUniqueCandidateName(baseName, tempCandidates, undefined, true);
        const newSlot: CandidateItem = {
          id: `cand-slot-${Date.now()}-${i}`,
          name: uniqueName,
          resumeText: '',
          status: 'idle',
        };
        newSlots.push(newSlot);
        tempCandidates.push(newSlot);
        tempCounter++;
      }

      setCandidateCounter(tempCounter);
      return tempCandidates;
    });
  };

  // Bulk add candidates from multi-file upload
  // Bulk add candidates from multi-file upload (preserves EVERY uploaded resume)
  const handleBulkAddCandidates = (
    newFiles: Array<{ name: string; resumeText: string; fileName: string }>
  ) => {
    if (newFiles.length === 0) return;

    setCandidates((prev) => {
      // Check if all existing candidate slots are blank/empty
      const allExistingAreEmpty = prev.every((c) => !c.resumeText.trim());
      const usedNames = new Set<string>();
      if (!allExistingAreEmpty) {
        prev.forEach((c) => {
          if (c.resumeText.trim()) {
            usedNames.add(c.name.trim().toLowerCase());
          }
        });
      }

      // Helper to assign a clean, guaranteed unique name for every candidate
      const makeUniqueName = (desiredName: string, index: number): string => {
        let base = desiredName.trim() || `Candidate ${index + 1}`;
        let candidateName = base;
        let counter = 2;

        const isGeneric = /^candidate(\s*\d+)?$/i.test(base);
        if (isGeneric) {
          let num = index + 1;
          candidateName = `Candidate ${num}`;
          while (usedNames.has(candidateName.toLowerCase())) {
            num++;
            candidateName = `Candidate ${num}`;
          }
        } else {
          const cleanBase = base.replace(/\s*(\(\d+\)|\b\d+)$/, "").trim() || base;
          while (usedNames.has(candidateName.toLowerCase())) {
            candidateName = `${cleanBase} (${counter})`;
            counter++;
          }
        }
        usedNames.add(candidateName.toLowerCase());
        return candidateName;
      };

      if (allExistingAreEmpty) {
        // Direct 1-to-1 conversion: exactly newFiles.length candidates created!
        const timestamp = Date.now();
        const brandNewCandidates: CandidateItem[] = newFiles.map((file, idx) => ({
          id: `cand-${timestamp}-${idx}`,
          name: makeUniqueName(file.name, idx),
          resumeText: file.resumeText,
          fileName: file.fileName,
          status: "idle",
        }));

        setTimeout(() => {
          if (brandNewCandidates.length > 0) {
            setSelectedCandidateId(brandNewCandidates[0].id);
          }
        }, 0);

        return brandNewCandidates;
      }

      // If user had existing filled candidates:
      // Fill any open empty slots first, then append brand new slots for the rest
      let updated = [...prev];
      let fileIdx = 0;

      // 1. Fill open empty slots
      for (let i = 0; i < updated.length && fileIdx < newFiles.length; i++) {
        if (!updated[i].resumeText.trim()) {
          const file = newFiles[fileIdx];
          updated[i] = {
            ...updated[i],
            name: makeUniqueName(file.name, fileIdx),
            resumeText: file.resumeText,
            fileName: file.fileName,
            status: "idle",
            result: undefined,
            error: undefined,
          };
          fileIdx++;
        }
      }

      // 2. Append all remaining files as new candidate slots
      const remainingCreated: CandidateItem[] = [];
      const timestamp = Date.now();
      while (fileIdx < newFiles.length) {
        const file = newFiles[fileIdx];
        remainingCreated.push({
          id: `cand-bulk-${timestamp}-${fileIdx}`,
          name: makeUniqueName(file.name, fileIdx),
          resumeText: file.resumeText,
          fileName: file.fileName,
          status: "idle",
        });
        fileIdx++;
      }

      const combined = [...updated, ...remainingCreated];

      setTimeout(() => {
        if (remainingCreated.length > 0) {
          setSelectedCandidateId(remainingCreated[0].id);
        }
      }, 0);

      return combined;
    });
  };

  // Clear all candidates back to 1 clean empty slot
  const handleClearAllCandidates = () => {
    const initialId = `cand-${Date.now()}`;
    setCandidates([
      {
        id: initialId,
        name: "Candidate 1",
        resumeText: "",
        status: "idle",
      },
    ]);
    setSelectedCandidateId(initialId);
  };

  const handleRemoveCandidate = (id: string) => {
    if (candidates.length <= 1) return;
    const remaining = candidates.filter((c) => c.id !== id);
    setCandidates(remaining);
    if (selectedCandidateId === id) {
      setSelectedCandidateId(remaining[0].id);
    }
  };

  // Update candidate
  const handleUpdateCandidate = (id: string, updates: Partial<CandidateItem>) => {
    setCandidates((prev) => {
      return prev.map((c) => (c.id === id ? { ...c, ...updates } : c));
    });
  };

  // Reset workspace completely to blank slate
  const handleReset = () => {
    const initialId = `cand-${Date.now()}`;
    setJobDescription('');
    setCandidates([
      {
        id: initialId,
        name: 'Candidate 1',
        resumeText: '',
        status: 'idle',
      },
    ]);
    setSelectedCandidateId(initialId);
    setErrorMessage(null);
    setBatchProgress(null);
  };

  const canEvaluateCurrent = Boolean(
    jobDescription.trim() && selectedCandidate?.resumeText.trim()
  );
  const populatedCandidatesCount = candidates.filter(
    (c) => c.resumeText && c.resumeText.trim().length > 0
  ).length;
  const canEvaluateAll = Boolean(
    jobDescription.trim() && populatedCandidatesCount > 0
  );

  return (
    <div className="min-h-screen bg-transparent text-[#F3F4F6] flex flex-col font-sans">
      {/* Top Header */}
      <Header
        onReset={handleReset}
        onOpenSettings={() => setIsSideDrawerOpen(true)}
        onOpenLegalModal={() => setIsLegalModalOpen(true)}
        isEvaluating={isEvaluating}
        hasData={hasAnyData}
      />

      {/* Main App Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Rubric Definition Banner */}
        <RubricInfo />

        {/* Batch Evaluation Live Progress Banner */}
        {batchProgress && (
          <div className="p-4 rounded-2xl bg-[#12151E]/80 backdrop-blur-md border border-white/[0.08] text-[#F3F4F6] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-5 h-5 border-2 border-sky-400 border-t-transparent rounded-full animate-spin shrink-0" />
              <div>
                <div className="text-xs sm:text-sm font-bold flex items-center gap-2">
                  <span>Batch Pool Evaluation in Progress:</span>
                  <span className="px-2 py-0.5 rounded-lg bg-sky-500/20 text-sky-200 border border-sky-500/30 font-mono text-xs">
                    {batchProgress.current} / {batchProgress.total}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Currently auditing candidate: <strong className="font-semibold text-white">{batchProgress.name}</strong>
                </p>
              </div>
            </div>
            <div className="w-full sm:w-48 bg-white/[0.06] rounded-full h-2 overflow-hidden border border-white/[0.06]">
              <div
                className="bg-sky-400 h-2 rounded-full transition-all duration-300"
                style={{ width: `${(batchProgress.current / batchProgress.total) * 100}%` }}
              />
            </div>
          </div>
        )}

        {/* Global Error Banner if API error occurs */}
        {errorMessage && (
          <div className="space-y-3">
            <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-800/60 text-rose-300 text-xs sm:text-sm flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
              <div className="flex-1">
                <span className="font-bold">Evaluation Error: </span>
                <span>{errorMessage}</span>
              </div>
              <button
                type="button"
                onClick={() => setErrorMessage(null)}
                className="text-rose-400 hover:text-rose-200 font-bold px-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {(errorMessage.toLowerCase().includes('quota') || errorMessage.includes('429')) && (
              <div className="p-5 rounded-xl bg-indigo-950/25 border border-indigo-800/40 text-indigo-200 text-xs sm:text-sm space-y-2">
                <h4 className="font-bold text-indigo-300 text-sm sm:text-base flex items-center gap-2">
                  <span>🚀 Partner's Guide to AI Quotas</span>
                </h4>
                <p className="leading-relaxed">
                  Hey partner, you hit the Google AI Studio free tier rate limit! This is a **fantastic sign** that you are testing heavily and preparing Vathmos for a true launch.
                </p>
                <p className="leading-relaxed font-semibold text-[#FAFAFA]">
                  Here is what you can do next:
                </p>
                <ul className="list-disc pl-5 space-y-1.5 text-indigo-300">
                  <li><strong>Wait 60 seconds:</strong> The free tier limits are calculated per-minute (RPM). Simply wait a minute, and your free limit will reset automatically!</li>
                  <li><strong>Enable Pay-As-You-Go (For launch):</strong> When you are ready to launch in 2026/2027, you can sit down with your parents and link a Google Cloud billing account. You get massive rate limits, and the pay-per-token pricing is incredibly cheap (and free for low volumes)!</li>
                </ul>
              </div>
            )}
          </div>
        )}

        {/* Input Workstations: Job Description vs Candidate Resume */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <JobDescriptionEditor
            value={jobDescription}
            onChange={setJobDescription}
            disabled={isEvaluating}
          />

          <ResumeEditor
            candidates={candidates}
            selectedCandidateId={selectedCandidateId}
            onSelectCandidate={setSelectedCandidateId}
            onAddCandidate={handleAddCandidate}
            onAdd10Slots={handleAdd10Slots}
            onBulkAddCandidates={handleBulkAddCandidates}
            onClearAllCandidates={handleClearAllCandidates}
            onRemoveCandidate={handleRemoveCandidate}
            onUpdateCandidate={handleUpdateCandidate}
            onEvaluateCurrent={() => handleEvaluateCandidate(selectedCandidateId)}
            onEvaluateAll={handleEvaluateAll}
            isEvaluating={isEvaluating}
            canEvaluate={canEvaluateCurrent}
            canEvaluateAll={canEvaluateAll}
            strictnessMode={strictnessMode}
            onStrictnessModeChange={handleStrictnessModeChange}
            minScoreFilter={minScoreFilter}
            autoExtractName={autoExtractName}
          />
        </div>

        {/* Multi-Candidate Comparison Leaderboard if >= 2 candidates evaluated */}
        {candidates.filter((c) => c.result).length >= 2 && (
          <LeaderboardView
            candidates={candidates}
            selectedCandidateId={selectedCandidateId}
            onSelectCandidate={setSelectedCandidateId}
            minScoreFilter={minScoreFilter}
            onMinScoreFilterChange={setMinScoreFilter}
            strictnessMode={strictnessMode}
          />
        )}

        {/* Active Candidate Scorecard */}
        {selectedCandidate?.result ? (
          <div id="active-candidate-scorecard" className="pt-2">
            <ScorecardView
              result={selectedCandidate.result}
              candidateName={selectedCandidate.name}
              candidateId={selectedCandidate.id}
              candidateResumeText={selectedCandidate.resumeText}
              jobDescription={jobDescription}
              onOpenJsonModal={() => setIsJsonModalOpen(true)}
              onOpenLegalModal={() => setIsLegalModalOpen(true)}
              onUpdateCandidateResult={(cId, updatedResult) => {
                setCandidates((prev) =>
                  prev.map((c) => (c.id === cId ? { ...c, result: updatedResult } : c))
                );
              }}
            />
          </div>
        ) : selectedCandidate?.status === 'evaluating' ? (
          <div className="bg-[#12151E]/80 backdrop-blur-md border border-white/[0.08] rounded-2xl p-8 sm:p-12 flex flex-col items-center justify-center text-center space-y-4 shadow-sm animate-pulse">
            <div className="relative flex items-center justify-center">
              <div className="w-12 h-12 rounded-full border-3 border-sky-500/25 border-t-sky-400 animate-spin" />
              <div className="absolute w-6 h-6 rounded-full bg-sky-500/15 flex items-center justify-center">
                <span className="w-2 h-2 rounded-full bg-sky-400" />
              </div>
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-bold text-white tracking-tight">
                Auditing {selectedCandidate.name} on 100-Point Rubric
              </h3>
              <p className="text-xs text-zinc-400 max-w-md mx-auto">
                Validating textual proof across Hard Requirements (0-40), Domain Architecture (0-30), and Verifiable Metrics (0-30).
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full max-w-lg pt-2 text-left">
              <div className="p-3 rounded-xl bg-[#0E1018]/80 border border-white/[0.06] text-xs">
                <p className="text-[10px] text-zinc-400 font-mono uppercase">Category 1</p>
                <p className="font-semibold text-white mt-0.5">Hard Requirements</p>
                <p className="text-[11px] text-sky-400">40 Points Max</p>
              </div>
              <div className="p-3 rounded-xl bg-[#0E1018]/80 border border-white/[0.06] text-xs">
                <p className="text-[10px] text-zinc-400 font-mono uppercase">Category 2</p>
                <p className="font-semibold text-white mt-0.5">Domain Depth</p>
                <p className="text-[11px] text-indigo-300">30 Points Max</p>
              </div>
              <div className="p-3 rounded-xl bg-[#0E1018]/80 border border-white/[0.06] text-xs">
                <p className="text-[10px] text-zinc-400 font-mono uppercase">Category 3</p>
                <p className="font-semibold text-white mt-0.5">Verifiable Evidence</p>
                <p className="text-[11px] text-emerald-400">30 Points Max</p>
              </div>
            </div>
          </div>
        ) : selectedCandidate?.status === 'error' ? (
          <div className="bg-rose-950/30 backdrop-blur-md border border-rose-800/40 rounded-2xl p-6 sm:p-8 flex flex-col items-center justify-center text-center space-y-3 shadow-sm">
            <div className="w-12 h-12 rounded-full bg-rose-900/40 flex items-center justify-center text-rose-300 ring-2 ring-rose-500/30">
              <AlertCircle className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm sm:text-base font-bold text-rose-200">
                Evaluation Failed for {selectedCandidate.name}
              </h3>
              <p className="text-xs text-rose-300 max-w-md mx-auto">
                {selectedCandidate.error || 'Temporary API connection error.'}
              </p>
            </div>
            <button
              type="button"
              onClick={() => handleEvaluateCandidate(selectedCandidate.id)}
              disabled={isEvaluating}
              className="mt-2 inline-flex items-center gap-2 px-5 py-2.5 bg-rose-600 hover:bg-rose-500 active:scale-[0.98] text-white rounded-xl text-xs font-bold transition-all duration-150 cursor-pointer shadow-xs disabled:opacity-50 min-h-[40px]"
            >
              Retry Evaluation
            </button>
          </div>
        ) : null}

        {/* Global Bottom Advisory / Disclaimer & Compliance Nav */}
        <footer className="pt-6 pb-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div className="flex items-center gap-3 flex-wrap">
            <Link
              href="/"
              className="inline-flex items-center gap-1 text-slate-300 hover:text-white font-semibold py-1 px-2.5 rounded-lg bg-slate-900 border border-slate-800 hover:border-slate-700 transition cursor-pointer"
            >
              <ArrowLeft className="w-3 h-3" />
              <span>Marketing Home</span>
            </Link>
            <p className="text-slate-400">
              <span className="text-slate-200 font-semibold">Vathmos Technologies:</span> Objective decision-support system.
            </p>
            <button
              type="button"
              id="footer-legal-charter-btn"
              onClick={() => setIsLegalModalOpen(true)}
              className="inline-flex items-center gap-1.5 text-amber-400 hover:text-amber-300 underline underline-offset-2 transition-colors cursor-pointer"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Quick Charter</span>
            </button>
          </div>

          <div className="flex items-center gap-4 text-slate-400 flex-wrap text-[11px]">
            <Link href="/privacy" className="hover:text-cyan-400 transition">Privacy Policy</Link>
            <span>•</span>
            <Link href="/terms" className="hover:text-cyan-400 transition">Terms of Service</Link>
            <span>•</span>
            <Link href="/refund" className="hover:text-cyan-400 transition">Refund Policy</Link>
            <span>•</span>
            <Link href="/contact" className="hover:text-cyan-400 transition">Contact Us</Link>
          </div>
        </footer>
      </main>

      {/* JSON Output Modal */}
      <JsonOutputModal
        isOpen={isJsonModalOpen}
        onClose={() => setIsJsonModalOpen(false)}
        result={selectedCandidate?.result || null}
        candidateName={selectedCandidate?.name || 'Candidate'}
      />

      {/* Side Slide Drawer for Settings, Extensions & Pipeline Modules */}
      <SideDrawer
        isOpen={isSideDrawerOpen}
        onClose={() => setIsSideDrawerOpen(false)}
        minScoreFilter={minScoreFilter}
        onMinScoreFilterChange={setMinScoreFilter}
        strictnessMode={strictnessMode}
        onStrictnessModeChange={handleStrictnessModeChange}
        autoExtractName={autoExtractName}
        onToggleAutoExtractName={setAutoExtractName}
      />

      {/* Legal, Privacy & Compliance Charter Modal */}
      <LegalCharterModal
        isOpen={isLegalModalOpen}
        onClose={() => setIsLegalModalOpen(false)}
      />

      {/* Recruiter Authentication & Profile Modals */}
      <AuthModal />
      <ProfileModal candidates={candidates} jobDescription={jobDescription} />
    </div>
  );
}
export default DashboardPage;
