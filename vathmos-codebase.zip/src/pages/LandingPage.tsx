import React, { useState } from 'react';
import { CreditCard, 
  Shield, 
  Sparkles, 
  ArrowRight, 
  FileText, 
  CheckCircle2, 
  Cpu, 
  Lock, 
  Zap, 
  Users, 
  Download, 
  ChevronRight, 
  Scale, 
  FileCheck, 
  Layers, 
  BarChart3, 
  ServerOff, 
  Flame, 
  Eye, 
  ExternalLink,
  Check,
  Star,
  Play,
  Mail
} from 'lucide-react';
import { Link, useRouter } from '../router/RouterContext';

export const LandingPage: React.FC = () => {
  const { navigate } = useRouter();
  const [selectedDemoCandidate, setSelectedDemoCandidate] = useState<'top' | 'gap'>('top');
  const [sampleModalOpen, setSampleModalOpen] = useState(false);
  const [pricingCycle, setPricingCycle] = useState<'usd' | 'inr'>('usd');

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-white relative overflow-x-hidden">
      {/* Background ambient radial glow effects */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[550px] bg-gradient-to-b from-sky-500/10 via-indigo-600/5 to-transparent blur-3xl pointer-events-none -z-10" />
      <div className="absolute top-[800px] left-0 w-[500px] h-[500px] bg-cyan-500/5 blur-3xl pointer-events-none -z-10" />
      <div className="absolute top-[1800px] right-0 w-[600px] h-[600px] bg-indigo-500/5 blur-3xl pointer-events-none -z-10" />

      {/* 1. Navigation Bar */}
      <header className="border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
          {/* Brand Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800 p-1 flex items-center justify-center text-white shadow-md overflow-hidden group">
              <img
                src="/src/assets/images/vathmos_logo_1789636779678.jpg"
                alt="Vathmos Mark"
                className="w-full h-full object-contain rounded-lg transition-transform duration-300 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <span className="text-2xl sm:text-3xl font-black tracking-tight text-white">Vathmos</span>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  100-PT RUBRIC
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-normal hidden sm:block">
                Technical Candidate Screening Engine
              </p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-7 text-xs font-semibold text-slate-300">
            <a href="#features" className="hover:text-cyan-400 transition">Features</a>
            <a href="#demo" className="hover:text-cyan-400 transition">Interactive Demo</a>
            <a href="#pricing" className="hover:text-cyan-400 transition">Pricing</a>
            <a href="#compliance" className="hover:text-cyan-400 transition">Compliance</a>
            <Link href="/contact" className="hover:text-cyan-400 transition">Contact Us</Link>
          </nav>

          {/* Primary CTA Button */}
          <div className="flex items-center gap-3">
            <Link
              href="/dashboard"
              className="inline-flex items-center gap-2 px-4 py-2 sm:px-5 sm:py-2.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 active:scale-[0.98] text-white text-xs sm:text-sm font-bold shadow-lg shadow-sky-500/20 transition-all duration-150 cursor-pointer"
            >
              <span>Launch App</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </header>

      {/* 2. Hero Section */}
      <section className="relative pt-12 sm:pt-20 pb-16 sm:pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full text-center space-y-8">
        {/* Eyebrow Pill */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-semibold bg-slate-900 border border-slate-800 text-slate-300 shadow-sm">
          <span className="flex h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
          <span className="text-white font-black tracking-wide text-sm">Vathmos</span>
          <span className="text-slate-500">•</span>
          <span>Zero Keyword-Stuffing Hallucinations</span>
        </div>

        {/* Catchy Headline */}
        <div className="space-y-4 max-w-4xl mx-auto">
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white leading-[1.08]">
            Objective Candidate Screening for{' '}
            <span className="text-cyan-400 sm:bg-gradient-to-r sm:from-sky-400 sm:via-cyan-300 sm:to-indigo-400 sm:bg-clip-text sm:text-transparent">
              Technical Teams
            </span>
          </h1>
          <p className="text-base sm:text-xl text-slate-300 max-w-2xl mx-auto font-normal leading-relaxed">
            Screen candidate resumes with zero bias and a deterministic 100-point rubric.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 pt-2">
          <button
            onClick={() => navigate('/dashboard')}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 active:scale-[0.98] text-white text-sm font-bold shadow-xl shadow-sky-500/25 transition-all cursor-pointer"
          >
            <span>Try Demo Free</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => setSampleModalOpen(true)}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 active:scale-[0.98] text-slate-200 hover:text-white border border-slate-800 hover:border-slate-700 text-sm font-semibold transition cursor-pointer"
          >
            <FileText className="w-4 h-4 text-cyan-400" />
            <span>View Sample PDF Leaderboard</span>
          </button>
        </div>

        {/* Trust Badges */}
        <div className="pt-4 flex flex-wrap items-center justify-center gap-y-2 gap-x-6 text-xs text-slate-400 font-medium">
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Transient In-Memory Evaluation</span>
          </div>
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>100-Point Deterministic Rubric</span>
          </div>
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Zero Long-Term Storage of Resumes</span>
          </div>
        </div>

        {/* Hero Visual Container: Framed Dynamic Scorecard / Leaderboard Interface */}
        <div className="pt-8 max-w-5xl mx-auto">
          <div className="relative rounded-2xl bg-gradient-to-b from-slate-800/80 via-slate-900/60 to-slate-950 p-1 sm:p-2.5 shadow-2xl shadow-sky-500/10 border border-slate-800 group">
            {/* Window bar */}
            <div className="px-4 py-3 bg-slate-950/90 rounded-t-xl border-b border-slate-800/80 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                  <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                </div>
                <span className="text-slate-400 font-mono text-[11px] ml-2">vathmos-screening-core://session/active-batch</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-900 text-slate-400 border border-slate-800 font-mono">
                  Standard 100-Point Rubric
                </span>
              </div>
            </div>

            {/* Scorecard Hero Mockup Content */}
            <div className="p-4 sm:p-6 bg-slate-950/70 rounded-b-xl text-left space-y-6">
              {/* Leaderboard Top Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800/80">
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                    <span>Target Role: Principal Distributed Systems Engineer</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-sky-500/15 text-sky-300 font-mono">JD #4029</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Evaluated against 100-Point Deterministic Standard Rubric • Batch Leaderboard Top Match
                  </p>
                </div>
                <button
                  onClick={() => navigate('/dashboard')}
                  className="inline-flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 font-semibold cursor-pointer"
                >
                  <span>Open Full Dashboard</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              {/* Top Candidate Showcase Card */}
              <div className="p-5 rounded-xl bg-slate-900/90 border border-cyan-500/30 shadow-lg space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 flex items-center justify-center font-bold text-sm">
                      #1
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-base font-extrabold text-white">Alex Rivera</h4>
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          QUALIFIED FOR ONSITE
                        </span>
                      </div>
                      <p className="text-xs text-slate-400">Senior Systems & Cloud Architect • 9 Years Experience</p>
                    </div>
                  </div>

                  <div className="flex items-baseline gap-2">
                    <div className="text-right">
                      <span className="text-3xl sm:text-4xl font-extrabold text-cyan-400">92</span>
                      <span className="text-sm font-semibold text-slate-400">/100</span>
                    </div>
                    <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-lg">
                      Top 2%
                    </span>
                  </div>
                </div>

                {/* 3 Pillars Breakdown Scores */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                  <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">Hard Requirements</span>
                      <span className="font-bold text-sky-400">38 / 40</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2">
                      <div className="bg-sky-400 h-1.5 rounded-full" style={{ width: '95%' }} />
                    </div>
                    <p className="text-[11px] text-slate-400 mt-2 line-clamp-1">
                      ✓ Distributed Go/Rust, Raft consensus, Kubernetes
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">Domain Architecture</span>
                      <span className="font-bold text-indigo-300">28 / 30</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2">
                      <div className="bg-indigo-400 h-1.5 rounded-full" style={{ width: '93%' }} />
                    </div>
                    <p className="text-[11px] text-slate-400 mt-2 line-clamp-1">
                      ✓ Multi-region partition fault tolerance, gRPC
                    </p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-400">Verifiable Evidence</span>
                      <span className="font-bold text-emerald-400">26 / 30</span>
                    </div>
                    <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2">
                      <div className="bg-emerald-400 h-1.5 rounded-full" style={{ width: '87%' }} />
                    </div>
                    <p className="text-[11px] text-slate-400 mt-2 line-clamp-1">
                      ✓ Reduced p99 latency by 44% at 1.2M QPS scale
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Core Feature Grid (3 Pillars) */}
      <section id="features" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-12 border-t border-slate-800/80">
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Sparkles className="w-3.5 h-3.5" />
            <span>The 3 Uncompromising Engineering Pillars</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Designed for Technical Recruiters Who Can't Afford False Positives
          </h2>
          <p className="text-sm text-slate-400">
            Traditional ATS filters rely on naive keywords. Vathmos audits genuine engineering proof.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Pillar 1 */}
          <div className="p-7 rounded-2xl bg-slate-900/50 border border-slate-800 hover:border-sky-500/40 transition-all duration-300 space-y-4 group">
            <div className="w-12 h-12 rounded-xl bg-sky-500/10 border border-sky-500/20 text-sky-400 flex items-center justify-center group-hover:scale-105 transition-transform">
              <Scale className="w-6 h-6" />
            </div>
            <div className="space-y-1.5">
              <span className="text-[11px] font-mono font-bold text-sky-400 uppercase tracking-wider">PILLAR 01</span>
              <h3 className="text-lg font-bold text-white">Deterministic 100-Point Rubric</h3>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Every score is strictly anchored across 3 clear categories: <strong className="text-slate-200">40 Hard Skills</strong> (binary qualification proof), <strong className="text-slate-200">30 Domain Depth</strong> (system architectural mastery), and <strong className="text-slate-200">30 Verifiable Evidence</strong> (quantified metrics & verifiable impact).
            </p>
            <div className="pt-2 text-xs text-sky-300 flex items-center gap-1.5 font-semibold">
              <span>Zero black-box guessing</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Pillar 2 */}
          <div className="p-7 rounded-2xl bg-slate-900/50 border border-slate-800 hover:border-emerald-500/40 transition-all duration-300 space-y-4 group">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center group-hover:scale-105 transition-transform">
              <ServerOff className="w-6 h-6" />
            </div>
            <div className="space-y-1.5">
              <span className="text-[11px] font-mono font-bold text-emerald-400 uppercase tracking-wider">PILLAR 02</span>
              <h3 className="text-lg font-bold text-white">Zero Data Retention (ZDR)</h3>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Candidate resumes and PII are parsed in volatile ephemeral RAM streams and flushed immediately upon report dispatch. We do not store candidate files on disks, and your private candidate submissions are <strong className="text-slate-200">never used to train public AI models</strong>.
            </p>
            <div className="pt-2 text-xs text-emerald-300 flex items-center gap-1.5 font-semibold">
              <span>Transient In-Memory Architecture</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Pillar 3 */}
          <div className="p-7 rounded-2xl bg-slate-900/50 border border-slate-800 hover:border-indigo-500/40 transition-all duration-300 space-y-4 group">
            <div className="w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center group-hover:scale-105 transition-transform">
              <FileCheck className="w-6 h-6" />
            </div>
            <div className="space-y-1.5">
              <span className="text-[11px] font-mono font-bold text-indigo-400 uppercase tracking-wider">PILLAR 03</span>
              <h3 className="text-lg font-bold text-white">Recruiter Co-Pilot & PDF Export</h3>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Deliver client-ready ranked leaderboards with 1-click professional PDF reports. Includes automated recruiter interview talking points, missing qualification warnings, and candidate red-flag detection.
            </p>
            <div className="pt-2 text-xs text-indigo-300 flex items-center gap-1.5 font-semibold">
              <span>Executive presentation ready</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>
      </section>

      {/* 4. Interactive Scorecard Comparison Demo */}
      <section id="demo" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-10 border-t border-slate-800/80">
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <Zap className="w-3.5 h-3.5" />
            <span>Interactive Evaluation Sandbox</span>
          </div>
          <h2 className="text-3xl font-extrabold text-white tracking-tight">
            See How the 100-Point Audit Separates True Depth From Fluff
          </h2>
          <p className="text-xs text-slate-400">
            Toggle between candidates below to witness how deterministic scoring catches missing hard skills.
          </p>
        </div>

        {/* Toggle */}
        <div className="flex justify-center">
          <div className="p-1 rounded-xl bg-slate-900 border border-slate-800 inline-flex items-center gap-1">
            <button
              onClick={() => setSelectedDemoCandidate('top')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                selectedDemoCandidate === 'top'
                  ? 'bg-cyan-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Candidate A: Alex Rivera (92 pts - Strong Hire)
            </button>
            <button
              onClick={() => setSelectedDemoCandidate('gap')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                selectedDemoCandidate === 'gap'
                  ? 'bg-rose-500 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Candidate B: Jordan Smith (64 pts - Hard Skill Gaps)
            </button>
          </div>
        </div>

        {/* Card display */}
        <div className="max-w-4xl mx-auto p-6 sm:p-8 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-6">
          {selectedDemoCandidate === 'top' ? (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold text-white">Alex Rivera</h3>
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                      Tier 1 • High Recommendation
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    Verified textual proof for Raft consensus, Go memory profiling, and high-concurrency systems.
                  </p>
                </div>
                <div className="text-left sm:text-right">
                  <div className="text-3xl font-extrabold text-cyan-400">92 / 100</div>
                  <span className="text-[11px] text-slate-500 font-mono">CALIBRATION: STANDARD</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
                  <div className="flex justify-between font-bold">
                    <span className="text-slate-300">Hard Requirements</span>
                    <span className="text-sky-400">38/40</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Direct citation: "Engineered distributed stream pipeline in Go handling 850k events/sec with zero packet loss."
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
                  <div className="flex justify-between font-bold">
                    <span className="text-slate-300">Domain Architecture</span>
                    <span className="text-indigo-300">28/30</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Direct citation: "Architected multi-DC failover clusters using Consul and eBPF network observability."
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
                  <div className="flex justify-between font-bold">
                    <span className="text-slate-300">Verifiable Metrics</span>
                    <span className="text-emerald-400">26/30</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Direct citation: "Cut compute cloud expenditure by $320,000 annually via memory compaction algorithms."
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold text-white">Jordan Smith</h3>
                    <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">
                      Tier 3 • Missing Hard Requirements
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    Candidate has generic backend buzzwords but lacks mandatory distributed systems proof.
                  </p>
                </div>
                <div className="text-left sm:text-right">
                  <div className="text-3xl font-extrabold text-amber-400">64 / 100</div>
                  <span className="text-[11px] text-slate-500 font-mono">CALIBRATION: STANDARD</span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-950 border border-rose-900/40 space-y-2">
                  <div className="flex justify-between font-bold">
                    <span className="text-slate-300">Hard Requirements</span>
                    <span className="text-rose-400">22/40 (Penalty)</span>
                  </div>
                  <p className="text-[11px] text-rose-300/80 leading-relaxed">
                    Gap identified: No textual proof of Go or Rust concurrency. Candidate worked predominantly in high-level Python scripting.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
                  <div className="flex justify-between font-bold">
                    <span className="text-slate-300">Domain Architecture</span>
                    <span className="text-amber-400">22/30</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Good general API familiarity, but missing distributed consensus and partition handling experience.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
                  <div className="flex justify-between font-bold">
                    <span className="text-slate-300">Verifiable Metrics</span>
                    <span className="text-amber-400">20/30</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Vague resume bullets like "Responsible for high volume traffic" without quantitative metrics or latency figures.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* 5. Pricing Section */}
      <section id="pricing" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full space-y-12 border-t border-slate-800/80">
        <div className="text-center space-y-3 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <CreditCard className="w-3.5 h-3.5" />
            <span>Transparent Credit & Subscription Tiers</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Simple, High-Margin Pricing for Growing Teams
          </h2>
          <p className="text-sm text-slate-400">
            No convoluted per-seat penalties. Pay for what you screen with instant digital delivery.
          </p>

          {/* Currency Toggle */}
          <div className="pt-2 flex justify-center">
            <div className="p-1 rounded-xl bg-slate-900 border border-slate-800 inline-flex items-center gap-1 text-xs">
              <button
                onClick={() => setPricingCycle('usd')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition cursor-pointer ${
                  pricingCycle === 'usd' ? 'bg-slate-800 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                Global USD ($)
              </button>
              <button
                onClick={() => setPricingCycle('inr')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition cursor-pointer ${
                  pricingCycle === 'inr' ? 'bg-slate-800 text-white shadow-xs' : 'text-slate-400 hover:text-white'
                }`}
              >
                India INR (₹)
              </button>
            </div>
          </div>
        </div>

        {/* Featured Starter Pass + Comparison Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-6xl mx-auto items-stretch">
          {/* Card 1: Starter Pass (Primary Featured Tier) */}
          <div className="relative p-8 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 border-2 border-sky-500/60 shadow-xl shadow-sky-500/10 flex flex-col justify-between space-y-6">
            <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3.5 py-1 rounded-full bg-gradient-to-r from-sky-500 to-indigo-600 text-white text-[11px] font-extrabold tracking-wide uppercase shadow-md">
              Most Popular For Launch
            </div>

            <div className="space-y-4">
              <div className="space-y-1">
                <h3 className="text-xl font-bold text-white">Starter Pass</h3>
                <p className="text-xs text-slate-400">
                  Ideal for solo recruiters & boutique tech agencies launching active candidate searches.
                </p>
              </div>

              <div className="flex items-baseline gap-2 pt-2">
                <span className="text-4xl font-extrabold text-white">
                  {pricingCycle === 'usd' ? '$39' : '₹3,100'}
                </span>
                <span className="text-xs text-slate-400 font-medium">/ 150 evaluations bundle</span>
              </div>

              <ul className="space-y-3 pt-3 text-xs text-slate-300">
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span><strong className="text-white">150 Candidate Evaluations</strong> included</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span>Unlimited Job Description slots</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span>1-Click PDF Leaderboard & Scorecard Exports</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span>Recruiter Co-Pilot with interview talking points</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span>Zero Data Retention & In-RAM Privacy Guarantee</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span>7-Day Unused Credit Refund Protection</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => navigate('/dashboard')}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 active:scale-[0.98] text-white text-xs font-bold transition shadow-md shadow-sky-500/20 cursor-pointer"
            >
              Get Started with Starter Pass
            </button>
          </div>

          {/* Card 2: Pro Tier */}
          <div className="p-8 rounded-2xl bg-slate-900/40 border border-slate-800 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="space-y-1">
                <h3 className="text-xl font-bold text-white">Pro Recruiter</h3>
                <p className="text-xs text-slate-400">
                  For active staffing firms screening 100+ candidates weekly across multiple openings.
                </p>
              </div>

              <div className="flex items-baseline gap-2 pt-2">
                <span className="text-4xl font-extrabold text-white">
                  {pricingCycle === 'usd' ? '$79' : '₹6,400'}
                </span>
                <span className="text-xs text-slate-400 font-medium">/ 400 evaluations bundle</span>
              </div>

              <ul className="space-y-3 pt-3 text-xs text-slate-300">
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span><strong className="text-white">400 Candidate Evaluations</strong> included</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Batch upload up to 30 resumes simultaneously</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>All Starter features + Strict & Lenient calibrations</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>Priority email support & White-Glove onboarding</span>
                </li>
              </ul>
            </div>

            <button
              onClick={() => navigate('/dashboard')}
              className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-[0.98] text-white text-xs font-bold transition border border-slate-700 cursor-pointer"
            >
              Choose Pro Tier
            </button>
          </div>

          {/* Card 3: Agency Tier */}
          <div className="p-8 rounded-2xl bg-slate-900/40 border border-slate-800 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="space-y-1">
                <h3 className="text-xl font-bold text-white">Agency & Enterprise</h3>
                <p className="text-xs text-slate-400">
                  High-volume technical recruitment consultancies and enterprise hiring teams.
                </p>
              </div>

              <div className="flex items-baseline gap-2 pt-2">
                <span className="text-4xl font-extrabold text-white">
                  {pricingCycle === 'usd' ? '$119' : '₹9,800'}
                </span>
                <span className="text-xs text-slate-400 font-medium">/ 1,000 evaluations bundle</span>
              </div>

              <ul className="space-y-3 pt-3 text-xs text-slate-300">
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                  <span><strong className="text-white">1,000 Candidate Evaluations</strong> included</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                  <span>Lowest cost per evaluation: &lt; $0.12 / candidate</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                  <span>Custom scoring rubric calibration support</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <Check className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                  <span>Direct founder channel via Slack/Discord</span>
                </li>
              </ul>
            </div>

            <div className="space-y-2">
              <a
                href="mailto:vathmossupport@gmail.com?subject=Vathmos%20Agency%20%26%20Enterprise%20Inquiry"
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                <Mail className="w-4 h-4" />
                <span>Contact Enterprise Desk</span>
              </a>
              <p className="text-[11px] text-slate-400 text-center font-mono">
                Support: <span className="text-cyan-400">vathmossupport@gmail.com</span>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Compliance & Privacy Banner */}
      <section id="compliance" className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full border-t border-slate-800/80">
        <div className="p-8 sm:p-10 rounded-3xl bg-slate-900/60 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex items-center gap-2 text-cyan-400 text-xs font-bold">
              <Shield className="w-4 h-4" />
              <span>Privacy & Candidate Data Protection</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-white">
              Transient Evaluation. Resumes Kept Private.
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Vathmos evaluates candidate resumes in-session to generate objective 100-point scorecards. We do not use candidate resumes to train public AI models, and data is processed strictly for your evaluation session.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 shrink-0">
            <Link
              href="/privacy"
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold border border-slate-700 transition"
            >
              <span>Read Privacy Policy</span>
              <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
            </Link>
            <Link
              href="/terms"
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold border border-slate-700 transition"
            >
              <span>Terms of Service</span>
              <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
            </Link>
          </div>
        </div>
      </section>

      {/* 7. Compliance Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-12 px-4 sm:px-6 lg:px-8 mt-auto">
        <div className="max-w-7xl mx-auto space-y-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-8 border-b border-slate-800/60">
            {/* Brand Logo & Name */}
            <div className="space-y-2">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 p-1 flex items-center justify-center text-white">
                  <img
                    src="/src/assets/images/vathmos_logo_1789636779678.jpg"
                    alt="Vathmos"
                    className="w-full h-full object-contain rounded"
                  />
                </div>
                <span className="text-lg font-bold text-white tracking-tight">Vathmos Technologies</span>
              </div>
              <p className="text-xs text-slate-400 max-w-sm">
                Deterministic candidate intelligence and objective recruitment decision-support. Built for high-growth tech teams.
              </p>
            </div>

            {/* Direct Compliance Links */}
            <div className="flex flex-wrap items-center gap-6 text-xs text-slate-300 font-medium">
              <Link href="/privacy" className="hover:text-cyan-400 transition">Privacy Policy</Link>
              <Link href="/terms" className="hover:text-cyan-400 transition">Terms of Service</Link>
              <Link href="/refund" className="hover:text-cyan-400 transition">Refund & Cancellation Policy</Link>
              <Link href="/contact" className="hover:text-cyan-400 transition">Contact Us</Link>
              <Link href="/dashboard" className="text-cyan-400 hover:text-cyan-300 font-bold transition flex items-center gap-1">
                <span>Launch App</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
            <div className="space-y-1 text-center sm:text-left">
              <p className="text-slate-400 font-medium">
                © {new Date().getFullYear()} Vathmos. All rights reserved.
              </p>
              <p className="text-[11px] text-slate-500 max-w-xl">
                Deterministic 100-point candidate screening engine. Resumes are processed in transient memory for candidate evaluation.
              </p>
            </div>
            <div className="flex items-center gap-4 text-[11px] shrink-0">
              <a href="mailto:vathmossupport@gmail.com" className="text-cyan-400 hover:text-cyan-300 transition font-mono">
                vathmossupport@gmail.com
              </a>
            </div>
          </div>
        </div>
      </footer>

      {/* Sample PDF Leaderboard Modal Preview */}
      {sampleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="bg-slate-900 rounded-2xl max-w-2xl w-full p-6 border border-slate-800 shadow-2xl space-y-5 text-slate-100">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-base text-white">Sample Candidate Pool PDF Export</h3>
              </div>
              <button
                onClick={() => setSampleModalOpen(false)}
                className="text-slate-400 hover:text-white font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3 text-xs">
              <div className="flex items-center justify-between text-slate-300 font-semibold border-b border-slate-800/80 pb-2">
                <span>Leaderboard Rank</span>
                <span>Candidate</span>
                <span>Rubric Score</span>
                <span>Status</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-800/40">
                <span className="font-mono text-cyan-400 font-bold">#1 Top Match</span>
                <span className="font-bold text-white">Alex Rivera</span>
                <span className="font-mono text-cyan-400 font-bold">92 / 100</span>
                <span className="text-emerald-400">Onsite Qualified</span>
              </div>
              <div className="flex items-center justify-between py-1.5 border-b border-slate-800/40">
                <span className="font-mono text-slate-400">#2 Ranked</span>
                <span className="font-semibold text-white">Sarah Chen</span>
                <span className="font-mono text-sky-400 font-bold">86 / 100</span>
                <span className="text-emerald-400">Phone Screen</span>
              </div>
              <div className="flex items-center justify-between py-1.5">
                <span className="font-mono text-slate-400">#3 Ranked</span>
                <span className="font-semibold text-white">Jordan Smith</span>
                <span className="font-mono text-amber-400 font-bold">64 / 100</span>
                <span className="text-amber-400">Review Skill Gaps</span>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Every exported Vathmos PDF report features high-resolution vector charts, candidate interview question prompts, detected red-flag anomalies, and direct verbatim evidence excerpts from candidate CVs.
            </p>

            <div className="flex justify-end gap-3 pt-2">
              <button
                onClick={() => setSampleModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold cursor-pointer"
              >
                Close Preview
              </button>
              <button
                onClick={() => {
                  setSampleModalOpen(false);
                  navigate('/dashboard');
                }}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-sky-500 to-indigo-600 text-white text-xs font-bold hover:from-sky-400 hover:to-indigo-500 transition cursor-pointer"
              >
                Open Dashboard & Export Real PDF
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
