import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { UserProfile, StoredUserAccount } from '../types';
import {
  generateSalt,
  hashPassword,
  generateVerificationCode,
  validateEmailAddress,
  validatePasswordStrength,
} from '../utils/authSecurity';

export interface DispatchedCodeNotification {
  email: string;
  code: string;
  type: 'signup' | 'reset';
  timestamp: number;
}

interface AuthContextType {
  currentUser: UserProfile | null;
  isAuthenticated: boolean;
  signUp: (data: {
    name: string;
    email: string;
    password: string;
    companyName: string;
    role: string;
  }) => Promise<{ success: boolean; error?: string; code?: string }>;
  signIn: (
    email: string,
    password: string
  ) => Promise<{ success: boolean; error?: string; requireVerification?: boolean }>;
  verifyEmail: (
    email: string,
    code: string
  ) => Promise<{ success: boolean; error?: string }>;
  resendVerificationCode: (
    email: string
  ) => Promise<{ success: boolean; code?: string; error?: string }>;
  requestPasswordReset: (
    email: string
  ) => Promise<{ success: boolean; code?: string; error?: string }>;
  resetPassword: (
    email: string,
    code: string,
    newPassword: string
  ) => Promise<{ success: boolean; error?: string }>;
  updateProfile: (updates: Partial<UserProfile>) => void;
  signOut: () => void;
  isAuthModalOpen: boolean;
  authModalMode: 'signin' | 'signup' | 'verify' | 'forgot';
  openAuthModal: (mode?: 'signin' | 'signup' | 'verify' | 'forgot') => void;
  closeAuthModal: () => void;
  isProfileModalOpen: boolean;
  openProfileModal: () => void;
  closeProfileModal: () => void;
  dispatchedNotification: DispatchedCodeNotification | null;
  dismissDispatchedNotification: () => void;
}

const STORAGE_KEY = 'vathmos_current_user_session';
const ACCOUNTS_STORAGE_KEY = 'vathmos_registered_accounts_v1';

const AVATAR_COLORS = [
  '#6366F1', // Indigo
  '#10B981', // Emerald
  '#0EA5E9', // Sky Blue
  '#8B5CF6', // Purple
  '#EC4899', // Pink
  '#F59E0B', // Amber
];

// Seed admin account with salted SHA-256 hash
const INITIAL_SEED_ACCOUNT: StoredUserAccount = {
  id: 'usr-vathmos-admin',
  name: 'Vathmos Admin',
  email: 'vathmossupport@gmail.com',
  companyName: 'Vathmos',
  role: 'Platform Administrator',
  joinedAt: 'September 2026',
  avatarColor: '#6366F1',
  salt: 'vathmos_salt_brand',
  passwordHash: '7c80adf7866860b23dbd3edbae7121bbdfe170ad93c1ee1f2f228b58c40dd98a',
  isEmailVerified: true,
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load saved session or initialize as null (requires real sign-in)
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fallback
    }
    return null;
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<
    'signin' | 'signup' | 'verify' | 'forgot'
  >('signin');
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);
  const [dispatchedNotification, setDispatchedNotification] =
    useState<DispatchedCodeNotification | null>(null);

  // Initialize and ensure seed account is present in database
  const getStoredAccounts = useCallback((): StoredUserAccount[] => {
    try {
      const raw = localStorage.getItem(ACCOUNTS_STORAGE_KEY);
      if (raw) {
        const parsed: StoredUserAccount[] = JSON.parse(raw);
        // Ensure founder account exists
        const hasFounder = parsed.some(
          (acc) => acc.email.toLowerCase() === INITIAL_SEED_ACCOUNT.email.toLowerCase()
        );
        if (!hasFounder) {
          const updated = [...parsed, INITIAL_SEED_ACCOUNT];
          localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(updated));
          return updated;
        }
        return parsed;
      }
    } catch {
      // fallback
    }
    const initialList = [INITIAL_SEED_ACCOUNT];
    try {
      localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(initialList));
    } catch {
      // ignore
    }
    return initialList;
  }, []);

  const saveAccounts = useCallback((accounts: StoredUserAccount[]) => {
    try {
      localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(accounts));
    } catch {
      // ignore
    }
  }, []);

  // Sync session to localStorage
  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(currentUser));
      } else {
        localStorage.removeItem(STORAGE_KEY);
      }
    } catch {
      // ignore
    }
  }, [currentUser]);

  // Sign Up: strict validation, hashes password, generates 6-digit verification code
  const signUp = async (data: {
    name: string;
    email: string;
    password: string;
    companyName: string;
    role: string;
  }): Promise<{ success: boolean; error?: string; code?: string }> => {
    const cleanEmail = data.email.trim().toLowerCase();

    // 1. Email format & domain check
    const emailValidation = validateEmailAddress(cleanEmail);
    if (!emailValidation.valid) {
      return { success: false, error: emailValidation.error };
    }

    // 2. Password strength validation
    const passValidation = validatePasswordStrength(data.password);
    if (!passValidation.valid) {
      return { success: false, error: passValidation.error };
    }

    // 3. Name check
    if (!data.name.trim()) {
      return { success: false, error: 'Full name is required.' };
    }

    // 4. Check if account already exists
    const accounts = getStoredAccounts();
    const existing = accounts.find((acc) => acc.email.toLowerCase() === cleanEmail);
    if (existing && existing.isEmailVerified) {
      return {
        success: false,
        error: 'An account with this email address already exists. Please Sign In.',
      };
    }

    // Generate cryptographic salt and hash password
    const salt = generateSalt();
    const passwordHash = await hashPassword(data.password, salt);
    const verificationCode = generateVerificationCode();
    const expires = Date.now() + 10 * 60 * 1000; // 10 minutes

    const randomColor =
      AVATAR_COLORS[Math.floor(Math.random() * AVATAR_COLORS.length)];

    const newAccount: StoredUserAccount = {
      id: existing ? existing.id : `usr-${Date.now()}`,
      name: data.name.trim(),
      email: cleanEmail,
      companyName: data.companyName.trim() || 'Hiring Organization',
      role: data.role.trim() || 'Talent Acquisition',
      joinedAt: new Date().toLocaleDateString('en-US', {
        month: 'long',
        year: 'numeric',
      }),
      avatarColor: randomColor,
      salt,
      passwordHash,
      isEmailVerified: false,
      verificationCode,
      verificationCodeExpires: expires,
    };

    const updatedAccounts = [
      ...accounts.filter((acc) => acc.email.toLowerCase() !== cleanEmail),
      newAccount,
    ];
    saveAccounts(updatedAccounts);

    // Dispatch simulated verification notification
    setDispatchedNotification({
      email: cleanEmail,
      code: verificationCode,
      type: 'signup',
      timestamp: Date.now(),
    });

    return {
      success: true,
      code: verificationCode,
    };
  };

  // Verify Email Code
  const verifyEmail = async (
    email: string,
    code: string
  ): Promise<{ success: boolean; error?: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    const cleanCode = code.trim();

    if (!cleanCode || cleanCode.length !== 6) {
      return { success: false, error: 'Please enter a valid 6-digit verification code.' };
    }

    const accounts = getStoredAccounts();
    const account = accounts.find((acc) => acc.email.toLowerCase() === cleanEmail);

    if (!account) {
      return { success: false, error: 'Account not found. Please register first.' };
    }

    if (!account.verificationCode) {
      if (account.isEmailVerified) {
        return { success: true };
      }
      return { success: false, error: 'No verification code was requested.' };
    }

    if (account.verificationCode !== cleanCode) {
      return {
        success: false,
        error: 'Incorrect verification code. Please check the code and try again.',
      };
    }

    if (
      account.verificationCodeExpires &&
      Date.now() > account.verificationCodeExpires
    ) {
      return {
        success: false,
        error: 'Verification code has expired. Please request a new code.',
      };
    }

    // Mark as verified
    account.isEmailVerified = true;
    account.verificationCode = undefined;
    account.verificationCodeExpires = undefined;

    const updatedAccounts = accounts.map((acc) =>
      acc.email.toLowerCase() === cleanEmail ? account : acc
    );
    saveAccounts(updatedAccounts);

    // Set logged-in user profile
    const profile: UserProfile = {
      id: account.id,
      name: account.name,
      email: account.email,
      companyName: account.companyName,
      role: account.role,
      joinedAt: account.joinedAt,
      avatarColor: account.avatarColor,
      isEmailVerified: true,
    };

    setCurrentUser(profile);
    setIsAuthModalOpen(false);
    setDispatchedNotification(null);

    return { success: true };
  };

  // Resend verification code
  const resendVerificationCode = async (
    email: string
  ): Promise<{ success: boolean; code?: string; error?: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    const accounts = getStoredAccounts();
    const account = accounts.find((acc) => acc.email.toLowerCase() === cleanEmail);

    if (!account) {
      return { success: false, error: 'Account not found. Please sign up first.' };
    }

    const newCode = generateVerificationCode();
    account.verificationCode = newCode;
    account.verificationCodeExpires = Date.now() + 10 * 60 * 1000;

    saveAccounts(accounts);

    setDispatchedNotification({
      email: cleanEmail,
      code: newCode,
      type: 'signup',
      timestamp: Date.now(),
    });

    return { success: true, code: newCode };
  };

  // Sign In: strictly verifies password hash against salt. Rejects fake passwords!
  const signIn = async (
    email: string,
    password: string
  ): Promise<{ success: boolean; error?: string; requireVerification?: boolean }> => {
    const cleanEmail = email.trim().toLowerCase();

    // 1. Validate email format
    const emailValidation = validateEmailAddress(cleanEmail);
    if (!emailValidation.valid) {
      return { success: false, error: emailValidation.error };
    }

    if (!password) {
      return { success: false, error: 'Please enter your account password.' };
    }

    // 2. Lookup account
    const accounts = getStoredAccounts();
    const account = accounts.find((acc) => acc.email.toLowerCase() === cleanEmail);

    if (!account) {
      return {
        success: false,
        error:
          'No account found with this email address. Please click "Sign Up" to create your recruiter account.',
      };
    }

    // 3. Cryptographically verify password
    const enteredHash = await hashPassword(password, account.salt);
    if (enteredHash !== account.passwordHash) {
      return {
        success: false,
        error:
          'Incorrect password. Verification failed. Please enter the valid password you created for this account.',
      };
    }

    // 4. Check email verification status
    if (!account.isEmailVerified) {
      // Issue new verification code
      const code = generateVerificationCode();
      account.verificationCode = code;
      account.verificationCodeExpires = Date.now() + 10 * 60 * 1000;
      saveAccounts(accounts);

      setDispatchedNotification({
        email: cleanEmail,
        code,
        type: 'signup',
        timestamp: Date.now(),
      });

      return {
        success: false,
        requireVerification: true,
        error:
          'Your email address is pending verification. A 6-digit confirmation code has been dispatched.',
      };
    }

    // 5. Success: log in
    const profile: UserProfile = {
      id: account.id,
      name: account.name,
      email: account.email,
      companyName: account.companyName,
      role: account.role,
      joinedAt: account.joinedAt,
      avatarColor: account.avatarColor,
      isEmailVerified: true,
    };

    setCurrentUser(profile);
    setIsAuthModalOpen(false);
    setDispatchedNotification(null);

    return { success: true };
  };

  // Request password reset code
  const requestPasswordReset = async (
    email: string
  ): Promise<{ success: boolean; code?: string; error?: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    const accounts = getStoredAccounts();
    const account = accounts.find((acc) => acc.email.toLowerCase() === cleanEmail);

    if (!account) {
      return {
        success: false,
        error: 'No account registered with this email address.',
      };
    }

    const resetCode = generateVerificationCode();
    account.verificationCode = resetCode;
    account.verificationCodeExpires = Date.now() + 10 * 60 * 1000;
    saveAccounts(accounts);

    setDispatchedNotification({
      email: cleanEmail,
      code: resetCode,
      type: 'reset',
      timestamp: Date.now(),
    });

    return { success: true, code: resetCode };
  };

  // Reset password with verified code
  const resetPassword = async (
    email: string,
    code: string,
    newPassword: string
  ): Promise<{ success: boolean; error?: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    const cleanCode = code.trim();

    const passValidation = validatePasswordStrength(newPassword);
    if (!passValidation.valid) {
      return { success: false, error: passValidation.error };
    }

    const accounts = getStoredAccounts();
    const account = accounts.find((acc) => acc.email.toLowerCase() === cleanEmail);

    if (!account) {
      return { success: false, error: 'Account not found.' };
    }

    if (!account.verificationCode || account.verificationCode !== cleanCode) {
      return {
        success: false,
        error: 'Invalid password reset verification code.',
      };
    }

    if (
      account.verificationCodeExpires &&
      Date.now() > account.verificationCodeExpires
    ) {
      return {
        success: false,
        error: 'Reset verification code has expired. Please request a new one.',
      };
    }

    // Set new password
    const newSalt = generateSalt();
    const newHash = await hashPassword(newPassword, newSalt);

    account.salt = newSalt;
    account.passwordHash = newHash;
    account.isEmailVerified = true;
    account.verificationCode = undefined;
    account.verificationCodeExpires = undefined;

    saveAccounts(accounts);
    setDispatchedNotification(null);

    return { success: true };
  };

  const updateProfile = (updates: Partial<UserProfile>) => {
    if (!currentUser) return;
    const updated: UserProfile = {
      ...currentUser,
      ...updates,
    };
    setCurrentUser(updated);

    try {
      const accounts = getStoredAccounts();
      const updatedAccounts = accounts.map((acc) => {
        if (acc.email.toLowerCase() === currentUser.email.toLowerCase()) {
          return {
            ...acc,
            name: updates.name ?? acc.name,
            companyName: updates.companyName ?? acc.companyName,
            role: updates.role ?? acc.role,
            avatarColor: updates.avatarColor ?? acc.avatarColor,
          };
        }
        return acc;
      });
      saveAccounts(updatedAccounts);
    } catch {
      // ignore
    }
  };

  const signOut = () => {
    setCurrentUser(null);
    setIsProfileModalOpen(false);
    setDispatchedNotification(null);
  };

  const openAuthModal = (
    mode: 'signin' | 'signup' | 'verify' | 'forgot' = 'signin'
  ) => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const openProfileModal = () => {
    setIsProfileModalOpen(true);
  };

  const closeProfileModal = () => {
    setIsProfileModalOpen(false);
  };

  const dismissDispatchedNotification = () => {
    setDispatchedNotification(null);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated: Boolean(currentUser),
        signUp,
        signIn,
        verifyEmail,
        resendVerificationCode,
        requestPasswordReset,
        resetPassword,
        updateProfile,
        signOut,
        isAuthModalOpen,
        authModalMode,
        openAuthModal,
        closeAuthModal,
        isProfileModalOpen,
        openProfileModal,
        closeProfileModal,
        dispatchedNotification,
        dismissDispatchedNotification,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
