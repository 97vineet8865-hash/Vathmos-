'use client';

import React from 'react';
import { DashboardPage } from '../../src/pages/DashboardPage';

export default function DashboardRoute() {
  return <DashboardPage />;
}
