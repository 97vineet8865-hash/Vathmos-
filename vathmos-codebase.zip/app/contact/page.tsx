'use client';

import React from 'react';
import { ContactPage } from '../../src/pages/ContactPage';

export default function ContactRoute() {
  return <ContactPage />;
}
