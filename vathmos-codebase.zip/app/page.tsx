'use client';

import React from 'react';
import { LandingPage } from '../src/pages/LandingPage';

export default function RootPage() {
  return <LandingPage />;
}
