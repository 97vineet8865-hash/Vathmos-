'use client';

import React from 'react';
import { PrivacyPolicyPage } from '../../src/pages/PrivacyPolicyPage';

export default function PrivacyRoute() {
  return <PrivacyPolicyPage />;
}
