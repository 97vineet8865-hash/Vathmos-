'use client';

import React from 'react';
import { RefundPolicyPage } from '../../src/pages/RefundPolicyPage';

export default function RefundRoute() {
  return <RefundPolicyPage />;
}
