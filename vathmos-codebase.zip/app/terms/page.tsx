'use client';

import React from 'react';
import { TermsPage } from '../../src/pages/TermsPage';

export default function TermsRoute() {
  return <TermsPage />;
}
