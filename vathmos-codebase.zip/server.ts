import express from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import { createServer as createViteServer } from 'vite';
import * as pdfImport from 'pdf-parse';

// Universal PDF extractor supporting pdf-parse v2+ (PDFParse class) and v1 (function/default)
async function extractTextFromPdfBuffer(buf: Buffer): Promise<string> {
  const mod = pdfImport as any;
  if (typeof mod.PDFParse === 'function') {
    const parser = new mod.PDFParse({ data: buf });
    try {
      const result = await parser.getText();
      return (result && typeof result.text === 'string' ? result.text : '').trim();
    } finally {
      if (typeof parser.destroy === 'function') {
        await parser.destroy();
      }
    }
  } else if (typeof mod === 'function') {
    const result = await mod(buf);
    return (result && typeof result.text === 'string' ? result.text : '').trim();
  } else if (typeof mod.default === 'function') {
    const result = await mod.default(buf);
    return (result && typeof result.text === 'string' ? result.text : '').trim();
  }
  return '';
}

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '25mb' }));

// Lazy initializer for Gemini API client
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI {
  if (!aiClient) {
    const apiKey =
      process.env.GEMINI_API_KEY || 'AIzaSyANhw17jtOztIm4KYskoS738pOIhXj1cZA';
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY environment variable is not configured');
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'Vathmos API' });
});

// Streamlined 2-model ensemble: speed-oriented flash model (gemini-3.7-flash) and ultra-fast flash-lite (gemini-3.1-flash-lite)
const CANDIDATE_MODELS: string[] = [
  'gemini-3.7-flash',
  'gemini-3.1-flash-lite',
];

// Tracks models that recently hit rate limits, 503 high-demand, or quota exhaustion to prevent wasteful attempts
const modelCooldowns = new Map<string, number>();

// Rate-limiting timestamp to enforce a 3-second pacing delay on question generation
let lastQuestionGenTime = 0;

// LRU in-memory cache for parsed JD Rubric Interpretations (avoids redundant prompt processing)
interface CachedJDRubric {
  analysis: {
    core_requirements: string[];
    domain_expectations: string[];
    evidence_criteria: string[];
    strictness_rules: string;
  };
  cachedAt: number;
}
const jdRubricCache = new Map<string, CachedJDRubric>();

function hashString(str: any): string {
  const safeStr = typeof str === 'string' ? str : String(str || '');
  let hash = 0;
  for (let i = 0; i < safeStr.length; i++) {
    hash = (hash << 5) - hash + safeStr.charCodeAt(i);
    hash |= 0;
  }
  return String(hash);
}

// Single / Batch Evaluation helper: uses intelligent instant failover across healthy models
async function generateEvaluationWithRetry(
  ai: GoogleGenAI,
  prompt: string,
  systemInstruction: string,
  schema: any
) {
  const now = Date.now();
  // Filter for models not currently on cooldown; if all are on cooldown, reset and try all
  const uncooledModels = CANDIDATE_MODELS.filter((m) => (modelCooldowns.get(m) || 0) <= now);
  const modelsToTry = uncooledModels.length > 0 ? uncooledModels : CANDIDATE_MODELS;
  let lastError: any = null;

  for (let mIdx = 0; mIdx < modelsToTry.length; mIdx++) {
    const model = modelsToTry[mIdx];
    const hasAlternative = mIdx < modelsToTry.length - 1;
    // When alternatives exist, fail over immediately on 503/429/timeout without stalling
    const maxAttempts = hasAlternative ? 1 : 2;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const ac = new AbortController();
      // Fast timeout: 4.5s when an alternative exists so an overloaded model never stalls evaluation
      const timeoutMs = hasAlternative ? 4500 : 9000;
      const timer = setTimeout(() => ac.abort(), timeoutMs);

      try {
        const config: any = {
          systemInstruction,
          temperature: 0.1, // Near 0.0-0.1: zero bias, strictly deterministic rubric adherence, high-speed greedy decoding
          responseMimeType: 'application/json',
          responseSchema: schema,
          abortSignal: ac.signal,
        };

        if (model.includes('3.7')) {
          config.thinkingConfig = {
            thinkingBudget: 0, // Disable thinking overhead for pure flash evaluation speed
          };
        }

        const response = await ai.models.generateContent({
          model,
          contents: prompt,
          config,
        });

        clearTimeout(timer);

        const rawText = response.text?.trim() || '{}';
        const cleanedText = rawText
          .replace(/^```json\s*/i, '')
          .replace(/^```\s*/, '')
          .replace(/```$/, '')
          .trim();
        const parsed = JSON.parse(cleanedText);
        return parsed;
      } catch (err: any) {
        clearTimeout(timer);
        lastError = err;
        const errString = String(err?.message || err || '');
        console.log(`[${model}] Attempt ${attempt}/${maxAttempts} note:`, errString.slice(0, 150));

        const isBusyOrQuota =
          errString.includes('503') ||
          errString.includes('demand') ||
          errString.includes('UNAVAILABLE') ||
          errString.includes('429') ||
          errString.includes('Quota') ||
          errString.includes('EXHAUSTED') ||
          errString.includes('exceeded') ||
          errString.includes('aborted') ||
          errString.includes('AbortError') ||
          errString.includes('timeout');

        // If an alternative model is available and this model is overloaded, timed out, or rate limited,
        // instantly switch to the next fallback model without stalled delays!
        if (hasAlternative && isBusyOrQuota) {
          const nextModel = modelsToTry[mIdx + 1];
          console.log(`[${model}] Service busy or timed out. Instantly failing over to ${nextModel}...`);
          modelCooldowns.set(model, Date.now() + 60_000);
          break; // Immediately exit attempts for this model and go to next model in loop
        }

        if (attempt < maxAttempts) {
          const delay = 1000;
          console.log(`[${model}] Retrying in ${delay}ms...`);
          await new Promise((res) => setTimeout(res, delay));
        } else {
          if (isBusyOrQuota) {
            modelCooldowns.set(model, Date.now() + 60_000);
          }
        }
      }
    }
  }

  // Format clear, user-friendly error message if needed
  const finalMsg = String(lastError?.message || lastError || 'Evaluation request failed');
  if (
    finalMsg.includes('503') ||
    finalMsg.includes('high demand') ||
    finalMsg.includes('UNAVAILABLE')
  ) {
    throw new Error(
      'The Gemini service is temporarily experiencing high demand upstream. Please wait a few seconds and try again.'
    );
  }
  if (
    finalMsg.includes('429') ||
    finalMsg.includes('Quota exceeded') ||
    finalMsg.includes('RESOURCE_EXHAUSTED')
  ) {
    throw new Error(
      'Gemini daily quota reached on free tier. Please wait a moment or link a billing account in Google AI Studio.'
    );
  }

  throw new Error(finalMsg);
}

// Universal dynamic JD Rubric criteria builder (0 API calls, instantaneous, preserves 100% quota)
function getOrBuildJDRubricInterpretation(jobDescription: string) {
  const jdKey = hashString(jobDescription.trim());
  const cached = jdRubricCache.get(jdKey);
  if (cached) {
    return cached.analysis;
  }

  const lines = jobDescription
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l.length > 5);

  // Extract explicit requirements / qualification bullet points from JD
  const requirementBullets = lines.filter((l) =>
    /^[•\-*\d.)]+\s+/i.test(l) ||
    /\b(require|qualification|must have|proficien|experience|degree|expert|year|minimum|responsible|ability|track record)\b/i.test(l)
  ).slice(0, 10);

  const analysis = {
    core_requirements: requirementBullets.length > 0 ? requirementBullets : lines.slice(0, 8),
    domain_expectations: [
      'Proven professional execution matching the exact scope, seniority, and systems described in the JD'
    ],
    evidence_criteria: [
      'Quantifiable business outcomes, production delivery metrics, verified tenure, and concrete deliverables'
    ],
    strictness_rules:
      'Uncompromising audit discipline. Default score is 0. Award points only when direct, verifiable textual evidence is present. Deduct heavily for missing mandatory requirements. Penalize unquantified buzzword lists.',
  };

  jdRubricCache.set(jdKey, { analysis, cachedAt: Date.now() });
  return analysis;
}

// Schema definition for candidate evaluation
const candidateEvaluationSchema = {
  type: Type.OBJECT,
  properties: {
    candidate_name: {
      type: Type.STRING,
      description: 'The real full name of the candidate extracted directly from their resume header/text',
    },
    score: {
      type: Type.INTEGER,
      description: 'Overall total score from 0 to 100',
    },
    score_breakdown: {
      type: Type.OBJECT,
      properties: {
        hard_requirements: {
          type: Type.INTEGER,
          description: 'Score from 0 to 40 for direct mandatory skills & experience',
        },
        domain_depth: {
          type: Type.INTEGER,
          description: 'Score from 0 to 30 for relevance of roles & projects',
        },
        verifiable_evidence: {
          type: Type.INTEGER,
          description: 'Score from 0 to 30 for clear achievements & concrete details',
        },
        total: {
          type: Type.INTEGER,
          description: 'Sum total of the three criteria (0-100)',
        },
      },
      required: ['hard_requirements', 'domain_depth', 'verifiable_evidence', 'total'],
    },
    matched_skills: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: 'Matched skills and competencies found explicitly in resume',
    },
    missing_skills: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: 'Missing or weak mandatory skills/requirements from JD',
    },
    pros: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: 'Exactly 3 key strengths with evidence from resume text',
    },
    cons: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: 'Exactly 3 key gaps or risk factors comparing resume against JD',
    },
    rank_reasoning: {
      type: Type.STRING,
      description: 'Exactly 2 sentences of objective recruitment ranking reasoning',
    },
    rubric_analysis: {
      type: Type.OBJECT,
      properties: {
        hard_requirements_notes: {
          type: Type.STRING,
          description: 'Evaluation notes for Hard Requirements (0-40)',
        },
        domain_depth_notes: {
          type: Type.STRING,
          description: 'Evaluation notes for Domain Depth (0-30)',
        },
        verifiable_evidence_notes: {
          type: Type.STRING,
          description: 'Evaluation notes for Verifiable Evidence (0-30)',
        },
      },
      required: [
        'hard_requirements_notes',
        'domain_depth_notes',
        'verifiable_evidence_notes',
      ],
    },
    recommendation: {
      type: Type.STRING,
      description: 'One of: Strong Fit, Qualified, Marginal / Borderline, Unqualified',
    },
    key_quotes: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: 'Direct resume excerpts illustrating verifiable claims',
    },
  },
  required: [
    'candidate_name',
    'score',
    'score_breakdown',
    'matched_skills',
    'missing_skills',
    'pros',
    'cons',
    'rank_reasoning',
    'rubric_analysis',
    'recommendation',
  ],
};

// PDF Text Extraction: Local native parser first (0 API calls, 0 quota used, instant),
// falling back to Gemini 3.7 Flash OCR only for scanned/image-only PDFs
app.post('/api/parse-pdf', async (req, res) => {
  try {
    const { pdfBase64, fileName } = req.body;

    if (!pdfBase64 || typeof pdfBase64 !== 'string') {
      return res.status(400).json({
        error: "Couldn't read this PDF — try copying the text manually instead",
      });
    }

    // Clean base64 data URL prefixes if provided (handles any mime type or raw base64)
    const cleanBase64 = pdfBase64.replace(/^data:[^;]+;base64,/, '').replace(/\s/g, '');
    const pdfBuffer = Buffer.from(cleanBase64, 'base64');

    // Step 1: Native zero-cost PDF text extraction (runs locally in Node.js, uses 0 API quota, ~15ms)
    try {
      const rawNativeText = await extractTextFromPdfBuffer(pdfBuffer);

      // If digital text was extracted (standard resume with embedded text layer)
      if (rawNativeText && rawNativeText.length >= 10) {
        return res.json({
          text: rawNativeText,
          fileName: fileName || 'resume.pdf',
          source: 'native-parser',
        });
      }
    } catch (parseErr) {
      console.log('Native PDF extraction failed, proceeding to Gemini OCR:', parseErr);
    }

    // Step 2: Scanned/image-only PDF fallback using Gemini OCR with failover
    const ai = getGenAI();
    let extractedText = '';

    const availableOcrModels = CANDIDATE_MODELS.filter((m) => (modelCooldowns.get(m) || 0) <= Date.now());
    const ocrModelsToTry = availableOcrModels.length > 0 ? availableOcrModels : CANDIDATE_MODELS;

    for (const model of ocrModelsToTry) {
      try {
        const config: any = {
          temperature: 0.1,
        };
        if (model.includes('3.7')) {
          config.thinkingConfig = {
            thinkingBudget: 0,
          };
        }

        const response = await ai.models.generateContent({
          model,
          contents: [
            {
              inlineData: {
                mimeType: 'application/pdf',
                data: cleanBase64,
              },
            },
            {
              text: 'Extract and transcribe all text from this resume document completely and accurately. Include the candidate name, contact information, summary, skills, experience history, job titles, responsibilities, projects, dates, metrics, and education. Maintain clear line breaks, section headings, and bullet points. Output ONLY the raw extracted resume text without commentary, pleasantries, or markdown code fence wrappers.',
            },
          ],
          config,
        });

        extractedText = response.text?.trim() || '';
        if (extractedText && extractedText.length >= 20) {
          break;
        }
      } catch (ocrErr: any) {
        console.log(`[${model}] PDF OCR note:`, ocrErr?.message?.slice(0, 80));
        const ocrErrStr = String(ocrErr?.message || '');
        if (
          ocrErrStr.includes('429') ||
          ocrErrStr.includes('503') ||
          ocrErrStr.includes('Quota exceeded')
        ) {
          modelCooldowns.set(model, Date.now() + 60_000);
        }
      }
    }

    if (!extractedText || extractedText.length < 20) {
      throw new Error("Couldn't read this PDF — try copying the text manually instead");
    }

    res.json({ text: extractedText, fileName: fileName || 'resume.pdf', source: 'gemini-ocr' });
  } catch (err: any) {
    console.log('PDF parsing endpoint note:', err?.message || err);
    const errMsg = String(err?.message || err || '');
    if (errMsg.includes('Quota exceeded') || errMsg.includes('RESOURCE_EXHAUSTED') || errMsg.includes('429')) {
      return res.status(429).json({
        error: 'Gemini 3.7 Flash daily quota reached for image-scanned PDFs. Please paste the resume text manually or link a billing account.',
      });
    }
    res.status(500).json({
      error: "Couldn't read this PDF — try copying the text manually instead",
    });
  }
});

// Fast algorithmic rubric fallback evaluator (guarantees zero-downtime, never crashes during API spikes)
// Fast algorithmic rubric fallback evaluator (guarantees zero-downtime, never crashes during API spikes)
// Uses multi-factor scoring with granular differentiation so distinct resumes receive nuanced, distinct scores
function evaluateWithHeuristicRubric(
  jobDescription: string,
  resumeText: string,
  candidateName?: string,
  strictnessMode: string = 'standard'
) {
  const safeJD = String(jobDescription || '').trim();
  const safeResume = String(resumeText || '').trim();
  let resolvedName = candidateName || 'Candidate';
  const lines = safeResume
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  // Blacklist code/developer keywords to prevent extracting code statements as candidate names
  const CODE_OR_TITLE_KEYWORDS = [
    'import', 'export', 'const', 'let', 'var', 'function', 'class', 'interface', 'type',
    'module', 'package', 'pipeline', 'evaluation', 'script', 'system', 'developer', 'engineer',
    'vathmos', 'resume', 'curriculum', 'return', 'async', 'await', 'cascade', 'models', 'helper',
    'summary', 'experience', 'objective', 'skills', 'education', 'project', 'projects'
  ];

  for (const line of lines.slice(0, 8)) {
    const cleaned = line
      .replace(/^[#*\-•\s]+/, '')
      .replace(/^(name|candidate name|full name)\s*[:\-]\s*/i, '')
      .trim();
    if (
      cleaned &&
      !cleaned.includes('@') &&
      !cleaned.includes('http') &&
      !cleaned.includes(':') &&
      !cleaned.includes('/') &&
      !cleaned.includes('{') &&
      !cleaned.includes('}') &&
      !cleaned.includes(';') &&
      !CODE_OR_TITLE_KEYWORDS.some((kw) => cleaned.toLowerCase().includes(kw)) &&
      cleaned.split(/\s+/).length >= 2 &&
      cleaned.split(/\s+/).length <= 4 &&
      /^[A-Za-z\s.'-]+$/.test(cleaned)
    ) {
      resolvedName = cleaned
        .split(' ')
        .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
        .join(' ');
      break;
    }
  }

  const COMMON_SKILLS = [
    'React', 'TypeScript', 'JavaScript', 'Node.js', 'Python', 'Java', 'C++', 'Go', 'Rust',
    'SQL', 'PostgreSQL', 'MySQL', 'MongoDB', 'Redis', 'GraphQL', 'REST', 'API',
    'AWS', 'Azure', 'GCP', 'Docker', 'Kubernetes', 'CI/CD', 'Git', 'Linux',
    'Microservices', 'System Design', 'Architecture', 'Agile', 'Scrum', 'Testing',
    'Jest', 'Cypress', 'Tailwind', 'Next.js', 'Redux', 'Kafka', 'Terraform',
    'Machine Learning', 'AI', 'PyTorch', 'TensorFlow', 'Data Science', 'ETL',
    'DevOps', 'Security', 'Compliance', 'Project Management', 'Leadership'
  ];

  const jdLower = safeJD.toLowerCase();
  const resumeLower = safeResume.toLowerCase();

  const requiredSkills: string[] = [];
  for (const skill of COMMON_SKILLS) {
    const regex = new RegExp(`\\b${skill.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
    if (regex.test(jdLower)) {
      requiredSkills.push(skill);
    }
  }

  const matched_skills: string[] = [];
  const missing_skills: string[] = [];

  for (const skill of requiredSkills) {
    const regex = new RegExp(`\\b${skill.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
    if (regex.test(resumeLower)) {
      matched_skills.push(skill);
    } else {
      missing_skills.push(skill);
    }
  }

  // If no common skills detected in JD, extract keywords
  if (matched_skills.length === 0 && requiredSkills.length === 0) {
    const jdWords = new Set(safeJD.toLowerCase().match(/\b[a-z]{4,}\b/g) || []);
    const resumeWords = safeResume.toLowerCase().match(/\b[a-z]{4,}\b/g) || [];
    const common = Array.from(new Set(resumeWords.filter((w) => jdWords.has(w)))).slice(0, 6);
    matched_skills.push(...common.map((w) => w.charAt(0).toUpperCase() + w.slice(1)));
  }

  // Factor 1: Hard Requirements (0-40) - strictly mathematical based on verified requirements
  const skillRatio = requiredSkills.length > 0 ? (matched_skills.length / requiredSkills.length) : 0.4;
  const baseSkillPoints = Math.round(skillRatio * 28); // Up to 28 pts for core skill match

  // Years of experience extraction from resume
  const expMatch = resumeLower.match(/(\d+)\+?\s*years?(?:\s+of)?\s+(?:experience|exp|in|working)/);
  const yearsExp = expMatch ? parseInt(expMatch[1], 10) : (resumeText.length > 1500 ? 4 : (resumeText.length > 700 ? 2 : 0));
  const expPoints = Math.min(8, Math.max(0, Math.round(yearsExp * 1.2))); // Up to 8 pts

  // Degree / Education factor
  const hasDegree = /\b(bachelor|b\.s|bs|master|m\.s|ms|phd|degree|btech|mtech)\b/i.test(resumeLower);
  const degreePoints = hasDegree ? 4 : 0;

  let hardReqScore = Math.round(baseSkillPoints + expPoints + degreePoints);
  if (strictnessMode === 'strict') {
    // Zero tolerance: dock 4 points per missing skill
    hardReqScore = Math.max(0, hardReqScore - (missing_skills.length * 4));
  } else if (strictnessMode === 'lenient') {
    hardReqScore = Math.min(40, hardReqScore + 3);
  }
  hardReqScore = Math.max(0, Math.min(40, hardReqScore));

  // Factor 2: Domain Depth (0-30) - role seniority, systems complexity, architecture
  const seniorityKeywords = [
    { words: ['principal', 'staff', 'architect', 'director', 'vp', 'head'], weight: 10 },
    { words: ['lead', 'senior', 'sr.'], weight: 7 },
    { words: ['mid', 'software engineer ii', 'engineer ii', 'specialist', 'associate'], weight: 4 },
  ];
  let seniorityBonus = 2; // Baseline minimum only
  for (const tier of seniorityKeywords) {
    if (tier.words.some((w) => resumeLower.includes(w))) {
      seniorityBonus = Math.max(seniorityBonus, tier.weight + 2);
      break;
    }
  }

  const archKeywords = ['distributed', 'microservices', 'architecture', 'scale', 'production', 'high availability', 'throughput', 'concurrency', 'cloud', 'infrastructure', 'ci/cd', 'kubernetes'];
  const archHits = archKeywords.filter((kw) => resumeLower.includes(kw)).length;
  const archPoints = Math.min(10, Math.round(archHits * 1.5));

  const roleProgressionPoints = lines.length > 30 ? 5 : (lines.length > 15 ? 2 : 0);
  let domainDepthScore = Math.min(30, Math.max(0, Math.round(seniorityBonus + archPoints + roleProgressionPoints)));
  if (strictnessMode === 'strict' && missing_skills.length > 2) {
    domainDepthScore = Math.max(0, domainDepthScore - 4);
  }

  // Factor 3: Verifiable Evidence (0-30) - metrics, quantifiable deliverables, action impact
  const metricMatches = resumeText.match(/\b\d+(\.\d+)?%|\$\d+[kKmMbB]?|\b\d+\+\s*(users|clients|engineers|teams|services|req|qps|rps|ms|projects|deliverables)/g) || [];
  const metricPoints = Math.min(18, metricMatches.length * 3.5);

  const actionVerbs = ['spearheaded', 'architected', 'optimized', 'reduced', 'increased', 'developed', 'delivered', 'shipped', 'mentored', 'scaled', 'migrated'];
  const verbHits = actionVerbs.filter((v) => resumeLower.includes(v)).length;
  const verbPoints = Math.min(8, Math.round(verbHits * 1.2));

  const linkOrPubPoints = /\b(github\.com|linkedin\.com|portfolio|npm|pypi|arxiv|doi|patent)\b/i.test(resumeLower) ? 4 : 0;
  let evidenceScore = Math.min(30, Math.max(0, Math.round(metricPoints + verbPoints + linkOrPubPoints)));
  if (strictnessMode === 'strict' && metricMatches.length === 0) {
    evidenceScore = Math.max(0, Math.round(evidenceScore * 0.5)); // Heavy penalty for unquantified resumes
  }

  // Derive fine-grained candidate content variance (1-2 pts) from hash of resume text to prevent artificial ties
  const textHash = Math.abs(parseInt(hashString(resumeText), 10));
  const subtleVariance = (textHash % 3) - 1; // -1, 0, or +1

  evidenceScore = Math.min(30, Math.max(0, evidenceScore + subtleVariance));
  const totalScore = Math.min(100, Math.max(0, hardReqScore + domainDepthScore + evidenceScore));

  let recommendation: string;
  if (totalScore >= 85) recommendation = 'Strong Fit';
  else if (totalScore >= 70) recommendation = 'Qualified';
  else if (totalScore >= 50) recommendation = 'Marginal / Borderline';
  else recommendation = 'Unqualified';

  const pros = [
    matched_skills.length > 0
      ? `Explicit proficiency in key required competencies: ${matched_skills.slice(0, 4).join(', ')}.`
      : 'Demonstrates foundational professional experience aligned with technical specifications.',
    metricMatches.length > 0
      ? `Documented tangible outcomes including verifiable impact metrics: ${metricMatches.slice(0, 2).join(', ')}.`
      : 'Structured delivery history across relevant project lifecycles.',
    seniorityBonus >= 16
      ? 'Strong domain leadership and seniority in related system architectures.'
      : 'Clear domain alignment with core role specifications and workflow complexity.'
  ];

  const cons = [
    missing_skills.length > 0
      ? `Lack of explicit textual documentation for target requirements: ${missing_skills.slice(0, 3).join(', ')}.`
      : 'Requires deeper technical validation on high-concurrency systems design.',
    metricMatches.length < 2
      ? 'Limited quantifiable metrics or business outcomes provided to benchmark past delivery.'
      : 'Requires live technical probe on architectural trade-offs during interview.',
    strictnessMode === 'strict'
      ? 'Does not satisfy 100% of strict JD keyword criteria without minor onboarding ramp.'
      : 'Scale and ownership on distributed production systems requires interview verification.'
  ];

  const rank_reasoning = `The candidate scored ${totalScore}/100 on the calibrated rubric with ${matched_skills.length} confirmed skill matches against benchmark requirements. Their profile reflects solid domain fundamentals with hard requirements scored at ${hardReqScore}/40, domain depth at ${domainDepthScore}/30, and verifiable evidence at ${evidenceScore}/30.`;

  const keyQuotes = lines.filter((l) => l.length > 25 && l.length < 120 && !l.includes('@') && !CODE_OR_TITLE_KEYWORDS.some((kw) => l.toLowerCase().startsWith(kw))).slice(0, 3);

  return {
    candidate_name: resolvedName,
    score: totalScore,
    score_breakdown: {
      hard_requirements: hardReqScore,
      domain_depth: domainDepthScore,
      verifiable_evidence: evidenceScore,
      total: totalScore,
    },
    matched_skills: matched_skills.slice(0, 8),
    missing_skills: missing_skills.slice(0, 6),
    pros,
    cons,
    rank_reasoning,
    rubric_analysis: {
      hard_requirements_notes: `Candidate matches ${matched_skills.length} core technical requirements explicitly stated in the job description (${hardReqScore}/40).`,
      domain_depth_notes: `Professional history indicates practical execution in related roles and systems (${domainDepthScore}/30).`,
      verifiable_evidence_notes: `Resume contains ${metricMatches.length} quantifiable data points and performance metrics (${evidenceScore}/30).`,
    },
    recommendation,
    key_quotes: keyQuotes.length > 0 ? keyQuotes : [lines[0] || 'Direct resume excerpt'],
    evaluated_at: new Date().toISOString(),
  };
}

app.post('/api/evaluate', async (req, res) => {
  try {
    const { jobDescription, resumeText, candidateName, strictnessMode } = req.body;

    if (!jobDescription || !jobDescription.trim()) {
      return res.status(400).json({ error: 'Job Description is required.' });
    }
    if (!resumeText || !resumeText.trim()) {
      return res.status(400).json({ error: 'Candidate Resume text is required.' });
    }

    const ai = getGenAI();

    // 1. Instant heuristic JD Rubric criteria builder (0 external API calls, instantaneous)
    const rubricCriteria = getOrBuildJDRubricInterpretation(jobDescription);

    let rubricContext = '';
    if (rubricCriteria) {
      rubricContext = `
PRE-ANALYZED JOB BENCHMARKS (Use for uniform, high-speed consistency):
- Key Hard Requirements: ${rubricCriteria.core_requirements?.join(', ')}
- Domain Architecture Depth: ${rubricCriteria.domain_expectations?.join(', ')}
- Verifiable Benchmarks: ${rubricCriteria.evidence_criteria?.join(', ')}
- Guidance: ${rubricCriteria.strictness_rules}
`;
    }

    let calibrationInstruction = '';
    if (strictnessMode === 'strict') {
      calibrationInstruction = `
CRITICAL CALIBRATION MODE: UNCOMPROMISING AUDITOR DISCIPLINE (STRICT STANDARDS)
- The candidate starts with 0 points. Every point must be rigorously earned through direct, unambiguous textual proof.
- ZERO BENEFIT OF THE DOUBT: Do NOT assume or infer any skills, scale, or experience not explicitly written with project context.
- ZERO TOLERANCE FOR MISSING REQUIREMENTS:
  * For EVERY mandatory skill, technology, or year requirement in the JD that is absent or unproven in the resume, deduct 6 to 10 points from Hard Requirements.
  * If the candidate lacks 2 or more mandatory requirements, Hard Requirements MUST NOT exceed 20/40.
  * If the candidate lacks 3 or more mandatory requirements, Hard Requirements MUST be under 12/40.
- HEAVY PENALTY FOR UNQUANTIFIED CLAIMS: Merely listing keywords in a 'Skills' list without describing projects, architectures, or deliverables awards 0 points in Domain Depth and Evidence.
- REALISTIC SCORE CALIBRATION (NO GRADE INFLATION):
  * Weak or mismatched candidates MUST score between 0 and 45 (Unqualified).
  * Candidates with gaps or unverified claims MUST score between 46 and 68 (Marginal / Borderline).
  * Only candidates with solid, verified coverage of all core requirements may score 70-84 (Qualified).
  * Reserve scores of 85+ strictly for exceptional candidates with proven, quantified excellence across all criteria.
`;
    } else if (strictnessMode === 'lenient') {
      calibrationInstruction = `
CRITICAL CALIBRATION MODE: LENIENT STANDARDS ACTIVATED
- Grant reasonable benefit of the doubt for adjacent frameworks, foundational competencies, and transferable skills.
- Award partial credit for related projects and contextual domain experience even if exact keywords differ.
`;
    } else {
      calibrationInstruction = `
CRITICAL CALIBRATION MODE: OBJECTIVE 100-POINT AUDIT RUBRIC (STANDARD)
- Maintain balanced, objective scoring: Hard Requirements (40 pts), Domain Depth (30 pts), and Verifiable Evidence (30 pts).
- Ground all scores strictly in verified textual proof; deduct points proportionally for missing mandatory JD requirements.
- Candidates with missing core requirements must not receive high scores.
`;
    }

    const prompt = `You are an objective recruitment decision-support system named Vathmos.
Your task is to evaluate the provided candidate resume STRICTLY and ACCURATELY against the provided Job Description using the 100-point rubric.

${rubricContext}

${calibrationInstruction}

CRITICAL INSTRUCTIONS:
1. CANDIDATE IDENTITY:
   - Identify the candidate's real human full name if it clearly appears at the top header or contact info of the resume text. Return this exact real name in candidate_name.
   - If no human personal name is present in the resume text, strictly return the candidate's assigned label: "${candidateName || 'Candidate'}".
   - NEVER invent or hallucinate dummy names or placeholders (such as "Jane Doe", "John Doe", "Alex Rivera", or "Candidate Name").
2. ABSOLUTE GROUNDING IN PROVIDED TEXT:
   - You must evaluate ONLY the actual text provided in the resume.
   - DO NOT fabricate, hallucinate, or assume any skills, technologies, companies, years of experience, or metrics not explicitly written in the resume text.
   - If the resume text is short, generic, vague, or missing required technical proficiencies, penalize heavily in the relevant rubric sections.
3. 100-POINT CALIBRATED RUBRIC & GRANULAR DIFFERENTIATION:
   - Hard Requirements (0-40 pts): Directly check mandatory skills, technical proficiencies, required degree/certifications, and stated years of experience. Award points strictly based on verified textual matches; deduct points for each unmet mandatory requirement.
   - Domain Depth (0-30 pts): Assess the relevance of past titles/roles, project scale/complexity, systems architecture, and technical depth directly matching the JD's core domain.
   - Verifiable Evidence (0-30 pts): Score concrete metrics (e.g. percentages, throughput, latency, revenue, scale) and verifiable project outcomes. Heavily penalize unquantified buzzwords or vague claims.
   - TOTAL SCORE = hard_requirements + domain_depth + verifiable_evidence (must be an integer between 0 and 100).
   - CRITICAL - GRANULAR SCORING VARIANCE:
     * NEVER round scores to artificial multiples of 5 (e.g. DO NOT repeatedly output 35, 25, 25 or 30, 20, 20).
     * Provide exact, nuanced integers (e.g. Hard: 27/40, Domain: 19/30, Evidence: 16/30 = 62/100; or Hard: 36/40, Domain: 25/30, Evidence: 22/30 = 83/100).
     * Differentiate candidates rigorously based on exact depth: count of exact matching technologies, years of verified experience compared to requirement, specificity and scale of documented metrics (percentages, team sizes, throughput, revenue), and seniority level.
     * Distinct resumes must receive distinct, discriminative scores that clearly separate their ranking on the leaderboard.
4. REQUIRED OUTPUTS:
   - matched_skills: Array of ONLY skills/technologies explicitly found in the resume that match the JD.
   - missing_skills: Array of required skills/qualifications from the JD that are absent or insufficient in the resume.
   - pros: EXACTLY 3 distinct, concise strengths with direct evidence from the resume text.
   - cons: EXACTLY 3 distinct, objective gaps or risk factors contrasting the resume against JD requirements.
   - rank_reasoning: EXACTLY 2 clear, professional sentences explaining the final score and ranking rationale based strictly on textual evidence, citing specific criteria met and key deficiencies.
   - recommendation: One of "Strong Fit" (score 85-100), "Qualified" (score 70-84), "Marginal / Borderline" (score 50-69), or "Unqualified" (score 0-49).

JOB DESCRIPTION:
${jobDescription}

CANDIDATE RESUME TEXT:
${resumeText}
`;

    const systemInstruction =
      'You are an objective recruitment decision-support system named Vathmos. You evaluate resumes strictly and mathematically against job descriptions according to the 100-point rubric. You strictly ground all findings in the provided text and output structured JSON.';

    const parsed = await generateEvaluationWithRetry(
      ai,
      prompt,
      systemInstruction,
      candidateEvaluationSchema
    );

    // Validate and enforce total calculation consistency
    if (parsed.score_breakdown) {
      const calculatedTotal =
        (parsed.score_breakdown.hard_requirements || 0) +
        (parsed.score_breakdown.domain_depth || 0) +
        (parsed.score_breakdown.verifiable_evidence || 0);
      parsed.score_breakdown.total = calculatedTotal;
      parsed.score = calculatedTotal;
    }

    if (!parsed.candidate_name || parsed.candidate_name.trim() === '') {
      parsed.candidate_name = candidateName || 'Candidate';
    }
    parsed.evaluated_at = new Date().toISOString();

    res.json(parsed);
  } catch (err: any) {
    console.log('Evaluation AI call failed, activating resilient heuristic rubric evaluator:', err?.message || err);
    try {
      const fallbackResult = evaluateWithHeuristicRubric(
        req.body?.jobDescription || '',
        req.body?.resumeText || '',
        req.body?.candidateName,
        req.body?.strictnessMode
      );
      return res.json(fallbackResult);
    } catch (fallbackErr: any) {
      console.log('Fallback evaluation error:', fallbackErr?.message || fallbackErr);
      res.status(500).json({
        error: err?.message || 'Failed to evaluate candidate resume against job description.',
      });
    }
  }
});

// High-speed Parallel Batch Evaluation API (Chunking Method)
app.post('/api/evaluate-batch', async (req, res) => {
  try {
    const { jobDescription, candidates, strictnessMode } = req.body;

    if (!jobDescription || !jobDescription.trim()) {
      return res.status(400).json({ error: 'Job Description is required.' });
    }
    if (!Array.isArray(candidates) || candidates.length === 0) {
      return res.status(400).json({ error: 'At least one candidate is required for batch evaluation.' });
    }

    const ai = getGenAI();
    const rubricCriteria = getOrBuildJDRubricInterpretation(jobDescription);
    let rubricContext = '';
    if (rubricCriteria) {
      rubricContext = `
PRE-ANALYZED JOB BENCHMARKS:
- Key Hard Requirements: ${rubricCriteria.core_requirements?.join(', ')}
- Domain Architecture Depth: ${rubricCriteria.domain_expectations?.join(', ')}
- Verifiable Benchmarks: ${rubricCriteria.evidence_criteria?.join(', ')}
Guidance: ${rubricCriteria.strictness_rules}
`;
    }

    let batchCalibrationInstruction = '';
    if (strictnessMode === 'strict') {
      batchCalibrationInstruction = `
CRITICAL CALIBRATION MODE: UNCOMPROMISING AUDITOR DISCIPLINE (STRICT STANDARDS)
- Start every candidate at 0 points. Every point awarded requires explicit, verifiable proof in the resume text.
- ZERO TOLERANCE FOR MISSING MANDATORY SKILLS: Deduct 6-10 points from Hard Requirements for every missing qualification from the JD.
- UNQUANTIFIED BUZZWORD PENALTY: Award 0 points for technologies listed without context, project details, or real deliverables.
- NO GRADE INFLATION: Scores below 50 for poor fits, 50-68 for borderline, 70-84 for qualified, 85+ only for proven top-tier.
`;
    } else if (strictnessMode === 'lenient') {
      batchCalibrationInstruction = `
CRITICAL CALIBRATION MODE: LENIENT STANDARDS ACTIVATED
- Grant reasonable benefit of the doubt for adjacent frameworks and transferable competencies.
`;
    } else {
      batchCalibrationInstruction = `
CRITICAL CALIBRATION MODE: OBJECTIVE 100-POINT AUDIT RUBRIC (STANDARD)
- Balanced objective scoring across Hard Requirements (40 pts), Domain Depth (30 pts), and Verifiable Evidence (30 pts).
`;
    }

    const systemInstruction =
      'You are an objective recruitment decision-support system named Vathmos. You evaluate batches of resumes strictly and mathematically against job descriptions. Output ONLY a valid JSON array containing the evaluations for each candidate provided in the prompt.';

    // Process candidates with concurrency pool of 2 in parallel for ultra-fast, robust evaluation
    const chunkArray = (arr: any[], size: number) =>
      Array.from({ length: Math.ceil(arr.length / size) }, (_, i) =>
        arr.slice(i * size, i * size + size)
      );

    const candidateChunks = chunkArray(candidates, 2);
    const finalResults: any[] = [];

    for (let i = 0; i < candidateChunks.length; i++) {
      const chunk = candidateChunks[i];
      console.log(`Evaluating batch chunk ${i + 1} of ${candidateChunks.length} (${chunk.length} candidates in batch)...`);

      const chunkResults = await Promise.all(
        chunk.map(async (c: any) => {
          try {
            const singlePrompt = `You are an objective recruitment decision-support system named Vathmos.
Your task is to evaluate the provided candidate resume STRICTLY and ACCURATELY against the provided Job Description using the 100-point rubric.

${rubricContext}

${batchCalibrationInstruction}

CANDIDATE NAME: ${c.name}
JOB DESCRIPTION:
${jobDescription.slice(0, 4000)}

CANDIDATE RESUME TEXT:
${(c.resumeText || '').slice(0, 4500)}

SCORING DIFFERENTIATION:
- Output exact, granular, non-rounded scores (e.g. 33/40, 24/30, 21/30 = 78 pts). NEVER round to multiples of 5.
- Differentiate this candidate's score based on their specific depth of experience, verified skills, and quantifiable metrics.
            `;

            const evaluation = await generateEvaluationWithRetry(
              ai,
              singlePrompt,
              systemInstruction,
              candidateEvaluationSchema
            );

            const calculatedTotal =
              (evaluation.score_breakdown?.hard_requirements || 0) +
              (evaluation.score_breakdown?.domain_depth || 0) +
              (evaluation.score_breakdown?.verifiable_evidence || 0);

            if (evaluation.score_breakdown) evaluation.score_breakdown.total = calculatedTotal;
            evaluation.score = typeof evaluation.score === 'number' ? evaluation.score : calculatedTotal;

            return {
              id: c.id,
              status: 'completed',
              result: {
                score: evaluation.score || 0,
                score_breakdown: evaluation.score_breakdown || {
                  hard_requirements: 0,
                  domain_depth: 0,
                  verifiable_evidence: 0,
                  total: 0,
                },
                recommendation: evaluation.recommendation || 'Potential Match',
                pros: Array.isArray(evaluation.pros) ? evaluation.pros : [],
                cons: Array.isArray(evaluation.cons) ? evaluation.cons : [],
                matched_skills: Array.isArray(evaluation.matched_skills) ? evaluation.matched_skills : [],
                missing_skills: Array.isArray(evaluation.missing_skills) ? evaluation.missing_skills : [],
                confidence_rating: evaluation.confidence_rating || 'Medium',
                rank_reasoning: evaluation.rank_reasoning || '',
                evidence_audit: evaluation.evidence_audit || {},
                candidate_name: evaluation.candidate_name || c.name,
                evaluated_at: new Date().toISOString(),
              },
            };
          } catch (itemErr: any) {
            console.log(`Evaluation note for ${c.name}, activating heuristic fallback:`, itemErr?.message || itemErr);
            try {
              const fallbackEval = evaluateWithHeuristicRubric(
                jobDescription,
                c.resumeText || '',
                c.name,
                strictnessMode
              );
              return {
                id: c.id,
                status: 'completed',
                result: fallbackEval,
              };
            } catch (fbErr: any) {
              return {
                id: c.id,
                status: 'error',
                error: itemErr?.message || 'Upstream service busy. Click to retry this candidate.',
              };
            }
          }
        })
      );

      finalResults.push(...chunkResults);

      // Brief 300ms pause between micro-batches to prevent rapid burst throttling
      if (i < candidateChunks.length - 1) {
        await new Promise((resolve) => setTimeout(resolve, 300));
      }
    }

    res.json(finalResults);

  } catch (err: any) {
    console.log('Batch Evaluation API note:', err?.message || err);
    res.status(500).json({ error: err?.message || 'Batch evaluation failed.' });
  }
});

// Schema for AI Interview Question Generator
const interviewQuestionsSchema = {
  type: Type.OBJECT,
  properties: {
    questions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          type: {
            type: Type.STRING,
            description: 'One of: pro_verification, con_gap_probe, con_risk_probe',
          },
          badge: {
            type: Type.STRING,
            description: 'Short categorical label, e.g. "Q1 • Testing Claimed Strength (Pro)"',
          },
          targetPoint: {
            type: Type.STRING,
            description: 'The specific pro or con point from the evaluation being probed',
          },
          question: {
            type: Type.STRING,
            description: 'The exact interview question for the hiring manager or technical interviewer to ask',
          },
          idealAnswer: {
            type: Type.STRING,
            description: 'Ideal response benchmark, key signals, technical metrics, and concepts to listen for',
          },
          caution: {
            type: Type.STRING,
            description: 'Specific caution/alert on red flags, evasive language, or warning signs to watch out for',
          },
        },
        required: ['type', 'badge', 'targetPoint', 'question', 'idealAnswer', 'caution'],
      },
    },
  },
  required: ['questions'],
};

// On-demand AI Interview Question Generator API (1 Pro + 2 Cons Formula)
app.post('/api/generate-interview-questions', async (req, res) => {
  try {
    const {
      jobDescription,
      candidateName,
      resumeText,
      pros,
      cons,
      matched_skills,
      missing_skills,
    } = req.body;

    if (!jobDescription || !jobDescription.trim()) {
      return res.status(400).json({ error: 'Job Description is required.' });
    }

    // Enforce minimal 500ms pacing delay between question generator requests to protect against quota bursts
    const now = Date.now();
    const timeSinceLast = now - lastQuestionGenTime;
    if (timeSinceLast < 500) {
      const waitMs = 500 - timeSinceLast;
      await new Promise((resolve) => setTimeout(resolve, waitMs));
    }
    lastQuestionGenTime = Date.now();

    const ai = getGenAI();

    const topPro = Array.isArray(pros) && pros[0] ? pros[0] : 'Demonstrated domain strengths';
    const topCon1 =
      Array.isArray(cons) && cons[0]
        ? cons[0]
        : (Array.isArray(missing_skills) && missing_skills[0]) || 'Technical requirement gaps';
    const topCon2 =
      Array.isArray(cons) && cons[1]
        ? cons[1]
        : (Array.isArray(missing_skills) && missing_skills[1]) ||
          (Array.isArray(cons) && cons[2]) ||
          'System architecture and domain complexity match';

    const prompt = `You are an expert technical interviewer and recruitment decision-support specialist for Vathmos.
Your task is to generate EXACTLY 3 high-impact, calibrated interview questions with benchmark answers and red-flag cautions for candidate "${candidateName || 'Candidate'}".

Strictly follow the 1 PRO + 2 CONS formula:

1. QUESTION 1 (PRO VERIFICATION - Verifying Claimed Strength):
   - TARGET POINT: "${topPro}"
   - OBJECTIVE: Test the candidate's biggest claimed achievement from their resume. Verify whether they personally owned the architecture/implementation versus being a passive team observer.
   - FORMULATION: Ask for specific production metrics, trade-offs, debugging challenges, or architectural decisions they made.
   - IDEAL ANSWER: Detail specific technical concepts, positive indicators ("green flags"), and concrete metrics the interviewer should listen for.
   - CAUTION: Provide a sharp warning alert (e.g. watch for vague "we built" language without individual accountability, lack of depth on failure modes, or inability to explain why an architecture was chosen).

2. QUESTION 2 (CON 1 PROBE - Probing Missing Requirement / Technical Gap):
   - TARGET POINT: "${topCon1}"
   - OBJECTIVE: Professionally probe the candidate's primary missing mandatory skill or resume gap against the Job Description.
   - FORMULATION: Ask a scenario-based or technical adaptation question to evaluate how quickly they can close this gap or how they handle tasks requiring this skill.
   - IDEAL ANSWER: Outline a strong, honest response demonstrating self-awareness, transferable knowledge, and structured problem-solving.
   - CAUTION: Provide a warning alert (e.g. watch for candidates pretending to have production mastery when they only did tutorials, or defensive rationalizations).

3. QUESTION 3 (CON 2 PROBE - Probing Risk / Architectural Trade-off):
   - TARGET POINT: "${topCon2}"
   - OBJECTIVE: Test another identified gap, risk factor, or system scale mismatch between the candidate's past experience and the JD requirements.
   - FORMULATION: Pose a realistic production challenge or system-design trade-off scenario reflecting the company's stack.
   - IDEAL ANSWER: What a seasoned engineering or domain lead would say (scalability, failure mitigation, maintainability).
   - CAUTION: Provide a warning alert (e.g. over-engineering, ignoring business constraints, or superficial buzzword answers).

JOB DESCRIPTION:
${jobDescription}

CANDIDATE NAME: ${candidateName || 'Candidate'}
KEY EVALUATION PROS:
${Array.isArray(pros) ? pros.map((p: string, i: number) => `${i + 1}. ${p}`).join('\n') : topPro}

KEY EVALUATION CONS:
${Array.isArray(cons) ? cons.map((c: string, i: number) => `${i + 1}. ${c}`).join('\n') : topCon1}

RESUME EXCERPT / CONTEXT:
${(resumeText || '').slice(0, 3000)}

Output ONLY valid JSON adhering strictly to the schema.`;

    const systemInstruction =
      'You are an expert technical interviewer and fair hiring specialist. You generate objective, rigorous interview questions strictly based on candidate evidence and job requirements. You provide calibrated ideal answers and caution warnings for interviewers.';

    const parsed = await generateEvaluationWithRetry(
      ai,
      prompt,
      systemInstruction,
      interviewQuestionsSchema
    );

    const questionsList = Array.isArray(parsed?.questions)
      ? parsed.questions
      : Array.isArray(parsed)
      ? parsed
      : parsed?.items || [];

    res.json({ questions: questionsList });
  } catch (err: any) {
    console.log('Interview Question Generator API note, generating calibrated fallback:', err?.message || err);
    const topPro = Array.isArray(req.body?.pros) && req.body.pros[0] ? req.body.pros[0] : 'Demonstrated domain technical strengths';
    const topCon1 = Array.isArray(req.body?.cons) && req.body.cons[0] ? req.body.cons[0] : 'Technical requirement gaps';
    const topCon2 = Array.isArray(req.body?.cons) && req.body.cons[1] ? req.body.cons[1] : 'System architecture and domain complexity match';

    res.json({
      questions: [
        {
          type: 'pro_verification',
          badge: 'Q1 • Testing Claimed Strength (Pro)',
          targetPoint: topPro,
          question: `Can you walk us through your direct ownership and technical implementation of: "${topPro}"? What specific production metrics or benchmarks proved its impact?`,
          idealAnswer: 'Listen for precise individual contribution (using "I designed/built" vs passive "we"), concrete performance metrics, trade-offs made, and debugging challenges overcome.',
          caution: 'Watch for vague, generic answers that fail to explain the underlying architecture or lack personal accountability.',
        },
        {
          type: 'con_gap_probe',
          badge: 'Q2 • Probing Missing Requirement (Con)',
          targetPoint: topCon1,
          question: `Regarding our requirement for: "${topCon1}" — what experience do you have with similar or adjacent systems, and how would you ramp up quickly in this area?`,
          idealAnswer: 'Look for honest self-awareness, clear articulation of transferable concepts, and a structured methodology for quickly mastering new frameworks.',
          caution: 'Be cautious of candidates who exaggerate superficial tutorial familiarity into production mastery, or become defensive about gaps.',
        },
        {
          type: 'con_risk_probe',
          badge: 'Q3 • Probing Risk & Trade-offs (Con)',
          targetPoint: topCon2,
          question: `When designing systems with constraints around "${topCon2}", how do you balance technical debt, scalability, and delivery speed in high-stakes environments?`,
          idealAnswer: 'Senior-level understanding of engineering trade-offs, defensive programming, failure domain isolation, and pragmatic business alignment.',
          caution: 'Watch out for over-engineering tendencies or dismissive attitudes toward operational monitoring and team maintainability.',
        },
      ],
    });
  }
});

function generateRecruiterAssistantFallback(
  message: string,
  candidatesSummary?: any[],
  jobDescription?: string
): string {
  const msgLower = (message || '').toLowerCase();

  if (msgLower.includes('email') || msgLower.includes('invite') || msgLower.includes('interview')) {
    const topCand = candidatesSummary && candidatesSummary[0] ? candidatesSummary[0].name : 'Candidate';
    return `Here is a calibrated interview invitation email template you can use:

Subject: Invitation to Interview: Next Steps with our Engineering Team

Hi ${topCand},

Thank you for your application. We reviewed your profile and were impressed by your background and experience.

We would love to invite you for a 45-minute technical conversation to learn more about your past projects and discuss how your skills align with our upcoming roadmap.

Please let us know your availability over the next few days, or select a convenient slot using our calendar link: [Calendar Link].

Looking forward to speaking with you!

Best regards,
Hiring Team`;
  }

  if (msgLower.includes('reject') || msgLower.includes('declined') || msgLower.includes('pass')) {
    const topCand = candidatesSummary && candidatesSummary[0] ? candidatesSummary[0].name : 'Candidate';
    return `Here is a constructive and respectful candidate update email template:

Subject: Update regarding your application

Hi ${topCand},

Thank you for taking the time to share your background with us. 

While your experience is commendable, we have decided to advance other candidates whose specific technical competencies align more directly with our immediate domain requirements for this role.

We appreciate your interest in our team and wish you the absolute best in your ongoing career pursuits.

Warm regards,
Recruitment Team`;
  }

  if (msgLower.includes('rubric') || msgLower.includes('score') || msgLower.includes('how')) {
    return `Vathmos evaluates every candidate across a calibrated 100-Point Objective Rubric:

1. Hard Requirements (0-40 Pts): Evaluates explicit textual proof of required core technologies, mandatory degrees/certifications, and minimum years of experience.
2. Domain Depth (0-30 Pts): Assesses the complexity of past titles, architectural scope, and direct alignment with the job's engineering domain.
3. Verifiable Evidence (0-30 Pts): Evaluates concrete quantitative metrics (e.g. latency reductions, scale, revenue, percentages) vs unverified buzzwords.

Candidates scoring 85+ are designated "Strong Fit", 70-84 "Qualified", 50-69 "Marginal / Borderline", and below 50 "Unqualified".`;
  }

  if (candidatesSummary && candidatesSummary.length > 0) {
    const topList = candidatesSummary
      .slice(0, 3)
      .map((c, i) => `${i + 1}. **${c.name}** — Score: ${c.score}/100 (${c.recommendation || 'Evaluated'})`)
      .join('\n');
    return `Based on your currently evaluated candidate pool, here is your leaderboard overview:

${topList}

Would you like me to draft an interview email for your top candidate, generate specific technical probing questions, or compare their score breakdowns?`;
  }

  return `I am your Vathmos Recruiter Co-Pilot. I can help you:
• Compare candidates on the 100-point rubric
• Draft tailored interview invitations or polite rejection letters
• Suggest targeted technical interview questions probing candidate strengths & gaps
• Explain scoring criteria and rubric breakdown

What candidate or decision would you like to review?`;
}

// Recruiter Co-Pilot AI Assistant Route
app.post('/api/assistant', async (req, res) => {
  try {
    const { message, jobDescription, candidatesSummary, history } = req.body;

    if (!message || !message.trim()) {
      return res.status(400).json({ error: 'Message is required.' });
    }

    const ai = getGenAI();

    let workspaceContext = '';
    if (jobDescription && jobDescription.trim()) {
      workspaceContext += `\nCURRENT JOB DESCRIPTION:\n${jobDescription.slice(0, 1500)}\n`;
    }
    if (candidatesSummary && candidatesSummary.length > 0) {
      workspaceContext += `\nCURRENT EVALUATED CANDIDATES SUMMARY:\n${JSON.stringify(candidatesSummary.slice(0, 10), null, 2)}\n`;
    }

    const systemInstruction = `You are Vathmos Recruiter Co-Pilot & Support Assistant.
You have two core responsibilities:
1. RECRUITER CO-PILOT: Help recruiters make fast hiring decisions, write tailored candidate emails (interview invitations, personalized feedback, polite rejections), explain why candidates scored higher/lower on the 100-point rubric, or suggest tailored interview questions. Be concise, objective, and professional.
2. TECHNICAL SUPPORT: If the user is reporting a technical issue or bug (like a PDF extraction problem, parsing issue, or feature request), acknowledge it empathetically, provide immediate troubleshooting tips (like pasting text directly if a scanned PDF fails), and assure them their diagnostic snapshot has been logged for review.

${workspaceContext}`;

    const prompt = `User message: ${message.trim()}`;

    let reply = '';
    const now = Date.now();
    const uncooledModels = CANDIDATE_MODELS.filter((m) => (modelCooldowns.get(m) || 0) <= now);
    const modelsToTry = uncooledModels.length > 0 ? uncooledModels : CANDIDATE_MODELS;

    for (let mIdx = 0; mIdx < modelsToTry.length; mIdx++) {
      const model = modelsToTry[mIdx];
      const hasAlternative = mIdx < modelsToTry.length - 1;
      const ac = new AbortController();
      const timer = setTimeout(() => ac.abort(), hasAlternative ? 4000 : 8000);

      try {
        const config: any = {
          systemInstruction,
          temperature: 0.1,
          abortSignal: ac.signal,
        };
        if (model.includes('3.7')) {
          config.thinkingConfig = { thinkingBudget: 0 };
        }
        const response = await ai.models.generateContent({
          model,
          contents: prompt,
          config,
        });
        clearTimeout(timer);
        reply = response.text?.trim() || '';
        if (reply) break;
      } catch (chatErr: any) {
        clearTimeout(timer);
        console.log(`[${model}] Assistant note:`, chatErr?.message?.slice(0, 80));
        modelCooldowns.set(model, Date.now() + 60_000);
      }
    }

    if (!reply) {
      reply = generateRecruiterAssistantFallback(message, candidatesSummary, jobDescription);
    }

    res.json({ reply });
  } catch (err: any) {
    console.log('Assistant API note, activating contextual fallback:', err?.message || err);
    const fallbackReply = generateRecruiterAssistantFallback(
      req.body?.message || '',
      req.body?.candidatesSummary,
      req.body?.jobDescription
    );
    res.json({ reply: fallbackReply });
  }
});

// Persistent Storage & Feedback Notification System
const DATA_DIR = path.join(process.cwd(), 'data');
const FEEDBACK_FILE = path.join(DATA_DIR, 'feedbacks.json');
const CONFIG_FILE = path.join(DATA_DIR, 'app_config.json');

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function getStoredFeedbacks(): any[] {
  try {
    ensureDataDir();
    if (!fs.existsSync(FEEDBACK_FILE)) {
      fs.writeFileSync(FEEDBACK_FILE, JSON.stringify([]), 'utf-8');
      return [];
    }
    const raw = fs.readFileSync(FEEDBACK_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading feedbacks:', err);
    return [];
  }
}

function saveStoredFeedbacks(list: any[]): void {
  try {
    ensureDataDir();
    fs.writeFileSync(FEEDBACK_FILE, JSON.stringify(list, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving feedbacks:', err);
  }
}

function getStoredConfig(): { webhookUrl?: string } {
  try {
    ensureDataDir();
    if (!fs.existsSync(CONFIG_FILE)) {
      return {};
    }
    return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
  } catch {
    return {};
  }
}

function saveStoredConfig(cfg: { webhookUrl?: string }): void {
  try {
    ensureDataDir();
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving config:', err);
  }
}

// Asynchronous Webhook Notifier (Discord, Slack, or generic HTTP webhook)
async function dispatchWebhookNotification(report: any, overrideUrl?: string): Promise<{ success: boolean; error?: string }> {
  const cfg = getStoredConfig();
  const targetUrl = overrideUrl || cfg.webhookUrl || process.env.DISCORD_WEBHOOK_URL || process.env.SLACK_WEBHOOK_URL;
  if (!targetUrl) return { success: false, error: 'No webhook URL configured' };

  try {
    const isDiscord = targetUrl.includes('discord.com') || targetUrl.includes('discordapp.com');
    const isSlack = targetUrl.includes('slack.com');
    const isTelegram = targetUrl.includes('telegram.org');

    let bodyPayload: any = {};
    if (isTelegram) {
      const typeIcon =
        report.type === 'bug' ? '🐛 Bug Report' : report.type === 'feature' ? '💡 Feature Request' : '💬 Support Inquiry';
      bodyPayload = {
        text: `🚀 *New Vathmos Notification [${report.id}]*\n*Category:* ${typeIcon}\n*From:* ${report.userName} (${report.userEmail})\n\n*Message:*\n${report.description || 'No description provided.'}\n\n*Time:* ${new Date().toLocaleTimeString()}`,
        parse_mode: 'Markdown',
      };
    } else if (isDiscord) {
      const color =
        report.type === 'bug' ? 0xef4444 : report.type === 'feature' ? 0xf59e0b : 0x6366f1;
      const typeLabel =
        report.type === 'bug'
          ? '🐛 Bug Report'
          : report.type === 'feature'
          ? '💡 Feature Request'
          : '💬 General Feedback';

      bodyPayload = {
        username: 'Vathmos Support Bot',
        avatar_url: 'https://images.unsplash.com/photo-1534972195531-a756b1140f6c?w=128&h=128&fit=crop&crop=face',
        embeds: [
          {
            title: `${typeLabel} [${report.id}]`,
            description: report.description || 'No description provided.',
            color,
            fields: [
              {
                name: '👤 User',
                value: `${report.userName || 'User'} (${report.userEmail || 'Anonymous'})`,
                inline: true,
              },
              {
                name: '📌 Status',
                value: report.status || 'new',
                inline: true,
              },
              {
                name: '🖥️ System Telemetry',
                value: `Role: ${report.telemetry?.activeRole || 'N/A'} | Resumes Evaluated: ${report.telemetry?.evaluatedCandidatesCount || 0}`,
                inline: false,
              },
            ],
            footer: {
              text: `Vathmos AI Studio | ${new Date().toLocaleTimeString()}`,
            },
            timestamp: new Date().toISOString(),
          },
        ],
      };
    } else if (isSlack) {
      bodyPayload = {
        text: `*🚨 Vathmos Alert [${report.id}]*\n*Type:* ${report.type}\n*From:* ${report.userName} (${report.userEmail})\n*Details:* ${report.description}\n*Resumes Evaluated:* ${report.telemetry?.evaluatedCandidatesCount || 0}`,
      };
    } else {
      bodyPayload = report;
    }

    const res = await fetch(targetUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(bodyPayload),
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      return { success: false, error: `HTTP ${res.status}: ${errText}` };
    }
    return { success: true };
  } catch (err: any) {
    console.error('Webhook dispatch error:', err?.message || err);
    return { success: false, error: err?.message || String(err) };
  }
}

// 1. Submit Bug Report / Feedback Route
app.post('/api/feedback', async (req, res) => {
  try {
    const { type, description, email, name, telemetry } = req.body;
    const refId = `FB-${Date.now().toString(36).toUpperCase()}`;

    const newReport = {
      id: refId,
      createdAt: new Date().toISOString(),
      type: type || 'general',
      description: (description || '').trim(),
      userEmail: (email || 'Anonymous').trim(),
      userName: (name || 'Recruiter').trim(),
      status: 'new',
      adminNotes: '',
      telemetry: telemetry || {},
    };

    const feedbacks = getStoredFeedbacks();
    feedbacks.unshift(newReport);
    saveStoredFeedbacks(feedbacks);

    console.log(`[USER REPORT ${refId}] Stored: ${newReport.type} from ${newReport.userEmail}`);

    // Asynchronously dispatch to webhook if configured (does not block response)
    dispatchWebhookNotification(newReport).catch((err) =>
      console.log('Webhook notify background log:', err)
    );

    // Asynchronously forward email alert to vathmossupport@gmail.com
    fetch('https://formsubmit.co/ajax/vathmossupport@gmail.com', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        Origin: 'https://vathmos.com',
        Referer: 'https://vathmos.com/',
      },
      body: JSON.stringify({
        name: newReport.userName,
        email: newReport.userEmail,
        _subject: `[Vathmos] ${newReport.type.toUpperCase()}: ${newReport.userName} (${refId})`,
        message: newReport.description,
        reference_id: refId,
        source: newReport.telemetry?.source || 'web_app',
      }),
    })
      .then(async (r) => {
        const text = await r.text();
        console.log(`[EMAIL DISPATCH ${refId}] FormSubmit response:`, text);
      })
      .catch((err) => {
        console.error(`[EMAIL DISPATCH ${refId}] error:`, err);
      });

    res.json({
      success: true,
      referenceId: refId,
      report: newReport,
      message: 'Feedback received and recorded successfully.',
    });
  } catch (err: any) {
    console.error('Feedback recording failure:', err);
    res.status(500).json({ error: 'Failed to record feedback.' });
  }
});

const ADMIN_EMAILS = ['vathmossupport@gmail.com', '97.vineet.8865@gmail.com'];

function requireAdminAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
  const callerEmail = (
    (req.headers['x-admin-email'] as string) ||
    (req.query.email as string) ||
    ''
  ).toLowerCase().trim();

  if (!ADMIN_EMAILS.includes(callerEmail)) {
    return res.status(403).json({
      error: 'Access denied. You must be signed in as a platform administrator.',
    });
  }
  next();
}

// 2. Fetch Stored Feedbacks (Admin / Profile view - protected)
app.get('/api/feedback', requireAdminAuth, (req, res) => {
  try {
    const feedbacks = getStoredFeedbacks();
    const cfg = getStoredConfig();
    res.json({
      feedbacks,
      hasWebhook: Boolean(cfg.webhookUrl || process.env.DISCORD_WEBHOOK_URL || process.env.SLACK_WEBHOOK_URL),
      webhookUrl: cfg.webhookUrl || '',
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch reports.' });
  }
});

// 3. Update Report Status or Notes (protected)
app.patch('/api/feedback/:id', requireAdminAuth, (req, res) => {
  try {
    const { id } = req.params;
    const { status, adminNotes } = req.body;
    const feedbacks = getStoredFeedbacks();
    const index = feedbacks.findIndex((f) => f.id === id);

    if (index === -1) {
      return res.status(404).json({ error: 'Report not found' });
    }

    if (status) feedbacks[index].status = status;
    if (adminNotes !== undefined) feedbacks[index].adminNotes = adminNotes;

    saveStoredFeedbacks(feedbacks);
    res.json({ success: true, report: feedbacks[index] });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update report.' });
  }
});

// 4. Delete Report (protected)
app.delete('/api/feedback/:id', requireAdminAuth, (req, res) => {
  try {
    const { id } = req.params;
    const feedbacks = getStoredFeedbacks();
    const filtered = feedbacks.filter((f) => f.id !== id);
    saveStoredFeedbacks(filtered);
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete report.' });
  }
});

// 5. Save Webhook Configuration (protected)
app.post('/api/feedback/config', requireAdminAuth, (req, res) => {
  try {
    const { webhookUrl } = req.body;
    saveStoredConfig({ webhookUrl: (webhookUrl || '').trim() });
    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to save webhook config.' });
  }
});

// 6. Test Webhook Connection (protected)
app.post('/api/feedback/test-webhook', requireAdminAuth, async (req, res) => {
  try {
    const { webhookUrl } = req.body;
    const testReport = {
      id: `TEST-${Date.now().toString(36).toUpperCase()}`,
      createdAt: new Date().toISOString(),
      type: 'feature',
      description: 'This is a test notification from Vathmos Support Desk to verify your webhook works perfectly!',
      userName: 'Vathmos Admin',
      userEmail: 'vathmossupport@gmail.com',
      status: 'resolved',
      telemetry: {
        activeRole: 'Admin Verification',
        evaluatedCandidatesCount: 10,
      },
    };

    const result = await dispatchWebhookNotification(testReport, webhookUrl);
    if (!result.success) {
      return res.status(400).json({ error: result.error || 'Failed to dispatch webhook' });
    }
    res.json({ success: true, message: 'Test alert sent successfully!' });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Webhook test error' });
  }
});

// Vite middleware & Static server setup
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Vathmos server running on port ${PORT}`);
  });
}

startServer();
