import React from 'react';
import { Download, RefreshCw, Check, Loader2, SlidersHorizontal, UserPlus, LogIn, ChevronDown, Shield, Home } from 'lucide-react';
import { Link } from '../router/RouterContext';
import { useAuth } from '../context/AuthContext';

interface HeaderProps {
  onReset: () => void;
  onOpenSettings: () => void;
  onOpenLegalModal?: () => void;
  isEvaluating: boolean;
  hasData: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  onReset,
  onOpenSettings,
  onOpenLegalModal,
  isEvaluating,
  hasData,
}) => {
  const { currentUser, openAuthModal, openProfileModal } = useAuth();
  const [downloadProgress, setDownloadProgress] = React.useState<number | null>(null);
  const [downloadDone, setDownloadDone] = React.useState<boolean>(false);

  const handleDownload = async () => {
    try {
      setDownloadProgress(10);
      setDownloadDone(false);
      const res = await fetch('/vathmos-dist-ready.zip');
      if (!res.ok) throw new Error('Download failed');
      
      const contentLength = res.headers.get('content-length');
      const total = contentLength ? parseInt(contentLength, 10) : 2860851;
      
      const reader = res.body?.getReader();
      if (!reader) {
        // Fallback standard navigation
        window.location.href = '/vathmos-dist-ready.zip';
        setDownloadDone(true);
        setTimeout(() => setDownloadDone(false), 4000);
        setDownloadProgress(null);
        return;
      }
      
      let received = 0;
      const chunks: Uint8Array[] = [];
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        if (value) {
          chunks.push(value);
          received += value.length;
          if (total > 0) {
            setDownloadProgress(Math.min(99, Math.round((received / total) * 100)));
          }
        }
      }
      
      const blob = new Blob(chunks, { type: 'application/zip' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'vathmos-dist-ready.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      setDownloadProgress(100);
      setDownloadDone(true);
      setTimeout(() => {
        setDownloadProgress(null);
        setDownloadDone(false);
      }, 3500);
    } catch (err) {
      console.error('Download error:', err);
      // Fallback direct link
      window.location.href = '/vathmos-dist-ready.zip';
      setDownloadProgress(null);
    }
  };


  const getInitials = (n: string) => {
    return n
      .split(' ')
      .map((part) => part[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <header className="border-b border-white/[0.07] bg-[#0A0C11]/80 backdrop-blur-xl sticky top-0 z-30 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3 group cursor-pointer" title="Back to Vathmos Home">
          <div className="w-10 h-10 rounded-xl bg-white/[0.04] p-1 flex items-center justify-center text-white shadow-xs ring-1 ring-white/[0.1] overflow-hidden group-hover:border-cyan-500/40 transition">
            <img
              src="/src/assets/images/vathmos_logo_1789636779678.jpg"
              alt="Vathmos Mark"
              className="w-full h-full object-contain rounded-lg transition-transform duration-300 group-hover:scale-105"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white group-hover:text-cyan-400 transition">
                Vathmos
              </h1>
              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-sky-500/10 text-sky-400 border border-sky-500/20 tracking-tight">
                100-Point Rubric
              </span>
            </div>
            <p className="text-xs text-zinc-400 hidden sm:block font-normal">
              Objective Recruitment Decision-Support System
            </p>
          </div>
        </Link>

        <div className="flex items-center gap-2 sm:gap-3">
          <Link
            href="/"
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl text-xs font-semibold text-slate-300 hover:text-white bg-slate-900/80 hover:bg-slate-800 border border-slate-800 transition cursor-pointer"
            title="Back to Marketing Home"
          >
            <Home className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Home</span>
          </Link>
          <button
            type="button"
            onClick={handleDownload}
            disabled={downloadProgress !== null}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-emerald-300 hover:text-white bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/25 transition-all cursor-pointer shadow-2xs disabled:opacity-75"
            title="Download complete Vathmos codebase (.zip) for Vercel / GitHub deployment"
          >
            {downloadProgress !== null ? (
              <>
                <Loader2 className="w-3.5 h-3.5 text-emerald-400 animate-spin" />
                <span>Downloading {downloadProgress}%</span>
              </>
            ) : downloadDone ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Downloaded!</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                <span className="hidden sm:inline">Download 1-Click Code (470KB)</span>
              </>
            )}
          </button>
          {onOpenLegalModal && (
            <button
              type="button"
              id="header-legal-charter-btn"
              onClick={onOpenLegalModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-amber-300 hover:text-white bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/25 transition-all cursor-pointer shadow-2xs"
              title="View In-RAM Ephemeral Processing, GDPR & EEOC Compliance Charter"
            >
              <Shield className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">Legal & Privacy</span>
            </button>
          )}

          <button
            type="button"
            id="open-settings-drawer-btn"
            onClick={onOpenSettings}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-zinc-200 bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] transition-all cursor-pointer shadow-2xs hover:text-white"
            title="Open filters, controls & future extensions"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-zinc-400" />
            <span className="hidden sm:inline">Options & Tools</span>
          </button>

          {hasData && (
            <button
              type="button"
              id="clear-workspace-btn"
              onClick={onReset}
              disabled={isEvaluating}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-zinc-400 hover:text-zinc-200 hover:bg-white/[0.04] border border-transparent hover:border-white/[0.08] transition-all disabled:opacity-50 cursor-pointer"
              title="Clear all fields and restart"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Clear Workspace</span>
            </button>
          )}

          {/* User Authentication & Profile Trigger */}
          {currentUser ? (
            <button
              type="button"
              id="user-profile-header-btn"
              onClick={openProfileModal}
              className="flex items-center gap-2 pl-2 pr-2.5 py-1 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] transition-all cursor-pointer shadow-2xs group"
              title="View recruiter profile & settings"
            >
              <div
                className="w-7 h-7 rounded-lg flex items-center justify-center text-[11px] font-bold text-white shadow-xs shrink-0"
                style={{ backgroundColor: currentUser.avatarColor || '#3B82F6' }}
              >
                {getInitials(currentUser.name)}
              </div>
              <div className="text-left hidden md:block">
                <p className="text-xs font-semibold text-zinc-200 leading-none group-hover:text-white truncate max-w-[110px]">
                  {currentUser.name}
                </p>
                <p className="text-[10px] text-zinc-400 leading-tight truncate max-w-[110px] mt-0.5">
                  {currentUser.companyName}
                </p>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-zinc-500 group-hover:text-zinc-300 transition-colors ml-0.5" />
            </button>
          ) : (
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                id="header-sign-in-btn"
                onClick={() => openAuthModal('signin')}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-medium text-zinc-400 hover:text-white hover:bg-white/[0.04] transition-all cursor-pointer"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In</span>
              </button>
              <button
                type="button"
                id="header-sign-up-btn"
                onClick={() => openAuthModal('signup')}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white transition-all cursor-pointer shadow-xs active:scale-[0.98]"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Sign Up</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
